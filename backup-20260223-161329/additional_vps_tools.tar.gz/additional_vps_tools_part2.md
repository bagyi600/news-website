snapshot.conf

# Usage
rsnapshot daily                               # Daily backup
rsnapshot weekly                              # Weekly backup
rsnapshot monthly                             # Monthly backup
```

### 🔄 **timeshift** - System Restore
```bash
# Install
sudo apt install timeshift -y

# Usage
sudo timeshift --create --comments "Before update" # Create snapshot
sudo timeshift --list                            # List snapshots
sudo timeshift --restore                         # Restore system
```

### 💽 **ddrescue** - Data Recovery
```bash
# Install
sudo apt install gddrescue -y

# Usage
ddrescue /dev/sda /dev/sdb mapfile.log         # Clone failing drive
ddrescue -r3 /dev/sda image.img mapfile.log    # Create image with retries
```

### 🗃️ **testdisk** / **photorec** - File Recovery
```bash
# Install
sudo apt install testdisk -y

# Usage
sudo testdisk                                  # Interactive recovery
sudo photorec                                  # Photo/file recovery
```

### 📊 **bacula** - Enterprise Backup
```bash
# Install
sudo apt install bacula-server bacula-client -y

# Complex setup, but powerful for enterprise backups
```

---

## 7. VIRTUALIZATION TOOLS

### 🐳 **docker** - Container Platform
```bash
# Install
sudo apt install docker.io docker-compose -y
sudo usermod -aG docker $USER

# Usage
docker ps                                      # List containers
docker images                                  # List images
docker run -it ubuntu bash                     # Run container
docker build -t myapp .                        # Build image
docker-compose up -d                           # Start compose stack
```

### 📦 **lxd** / **lxc** - System Containers
```bash
# Install
sudo apt install lxd lxc -y
sudo lxd init                                  # Initialize

# Usage
lxc launch ubuntu:22.04 mycontainer           # Launch container
lxc list                                      # List containers
lxc exec mycontainer bash                     # Execute in container
lxc snapshot mycontainer snap1                # Create snapshot
```

### 🖥️ **qemu-kvm** - Virtualization
```bash
# Install
sudo apt install qemu-kvm libvirt-daemon-system libvirt-clients bridge-utils virt-manager -y
sudo adduser $USER libvirt
sudo adduser $USER kvm

# Usage
virsh list --all                              # List VMs
virsh start vmname                            # Start VM
virsh shutdown vmname                         # Shutdown VM
```

### 🔄 **vagrant** - Development Environments
```bash
# Install
sudo apt install vagrant -y

# Usage
vagrant init ubuntu/focal64                   # Initialize
vagrant up                                    # Start VM
vagrant ssh                                   # SSH into VM
vagrant halt                                  # Stop VM
vagrant destroy                               # Destroy VM
```

### ☸️ **minikube** / **microk8s** - Kubernetes
```bash
# Install minikube
curl -LO https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64
sudo install minikube-linux-amd64 /usr/local/bin/minikube

# Install microk8s
sudo snap install microk8s --classic
sudo usermod -a -G microk8s $USER

# Usage
minikube start                                # Start cluster
microk8s status                               # Check status
microk8s enable dashboard dns registry       # Enable addons
```

### 🏗️ **terraform** - Infrastructure as Code
```bash
# Install
sudo apt install terraform -y

# Usage
terraform init                                # Initialize
terraform plan                                # Show changes
terraform apply                               # Apply changes
terraform destroy                             # Destroy infrastructure
```

### ☁️ **packer** - Machine Image Creation
```bash
# Install
sudo apt install packer -y

# Usage
packer build template.json                    # Build image
packer validate template.json                 # Validate template
```

---

## 8. MONITORING & ALERTING TOOLS

### 📊 **prometheus** - Monitoring System
```bash
# Install
sudo apt install prometheus -y

# Configuration
sudo systemctl start prometheus
sudo systemctl enable prometheus
# Access at http://localhost:9090
```

### 📈 **grafana** - Visualization Dashboard
```bash
# Install
sudo apt install grafana -y

# Usage
sudo systemctl start grafana-server
sudo systemctl enable grafana-server
# Access at http://localhost:3000 (admin/admin)
```

### 🚨 **alertmanager** - Alert Management
```bash
# Install with Prometheus
sudo apt install prometheus-alertmanager -y
```

### 📋 **netdata** - Real-time Monitoring
```bash
# Install
bash <(curl -Ss https://my-netdata.io/kickstart.sh)

# Usage
# Access at http://localhost:19999
# Auto-starts and monitors everything
```

### 🔍 **nagios** / **icinga** - Infrastructure Monitoring
```bash
# Install Nagios
sudo apt install nagios4 nagios-plugins -y

# Install Icinga2
sudo apt install icinga2 icinga2-ido-mysql monitoring-plugins -y

# Both are comprehensive monitoring solutions
```

### 📊 **zabbix** - Enterprise Monitoring
```bash
# Install
sudo apt install zabbix-server-mysql zabbix-frontend-php zabbix-apache-conf zabbix-agent -y

# Complete monitoring solution with web interface
```

### 📡 **telegraf** - Metrics Collector
```bash
# Install
sudo apt install telegraf -y

# Usage
telegraf --config telegraf.conf               # Run with config
# Collects metrics for InfluxDB, Prometheus, etc.
```

### 📝 **influxdb** - Time Series Database
```bash
# Install
sudo apt install influxdb -y

# Usage
sudo systemctl start influxdb
influx                                        # CLI interface
```

---

## 9. AUTOMATION SCRIPTS

### 🤖 **ansible** - Configuration Management
```bash
# Install
sudo apt install ansible -y

# Usage
ansible all -m ping                           # Test connectivity
ansible-playbook playbook.yml                 # Run playbook
ansible-galaxy install username.rolename      # Install roles
```

### ⚙️ **puppet** - Configuration Management
```bash
# Install
sudo apt install puppet -y

# Usage
puppet apply manifest.pp                      # Apply manifest
puppet agent --test                           # Test agent
```

### 🔧 **chef** - Infrastructure Automation
```bash
# Install Chef Workstation
curl -L https://omnitruck.chef.io/install.sh | sudo bash -s -- -P chef-workstation

# Usage
chef-client                                   # Run chef client
chef-solo                                     # Run in solo mode
```

### 🐍 **fabric** / **invoke** - Python Automation
```bash
# Install
pip3 install fabric invoke

# Usage
# Create fabfile.py with tasks, then:
fab deploy                                    # Run deploy task
invoke build                                  # Run build task
```

### 📜 **expect** - Automated Interactions
```bash
# Install
sudo apt install expect -y

# Example script (auto_ssh.exp):
#!/usr/bin/expect
spawn ssh user@host
expect "password:"
send "mypassword\r"
interact
```

### 🔄 **cron** Automation Scripts

**Daily Backup Script:**
```bash
#!/bin/bash
# /usr/local/bin/daily-backup.sh
BACKUP_DIR="/backup"
SOURCE_DIR="/data"
DATE=$(date +%Y%m%d)

# Create backup
tar -czf "$BACKUP_DIR/backup-$DATE.tar.gz" "$SOURCE_DIR"

# Keep only last 7 days
find "$BACKUP_DIR" -name "backup-*.tar.gz" -mtime +7 -delete

# Log
echo "$(date): Backup completed" >> /var/log/backup.log
```

**System Update Script:**
```bash
#!/bin/bash
# /usr/local/bin/auto-update.sh
LOG_FILE="/var/log/auto-update.log"

echo "=== Update started at $(date) ===" >> "$LOG_FILE"

# Update package lists
apt update >> "$LOG_FILE" 2>&1

# Upgrade packages
apt upgrade -y >> "$LOG_FILE" 2>&1

# Clean up
apt autoremove -y >> "$LOG_FILE" 2>&1
apt clean >> "$LOG_FILE" 2>&1

echo "=== Update completed at $(date) ===" >> "$LOG_FILE"
```

**Log Rotation Script:**
```bash
#!/bin/bash
# /usr/local/bin/rotate-logs.sh
LOG_DIR="/var/log/myapp"
DAYS_TO_KEEP=30

# Compress old logs
find "$LOG_DIR" -name "*.log" -mtime +$DAYS_TO_KEEP -exec gzip {} \;

# Delete very old logs
find "$LOG_DIR" -name "*.gz" -mtime +90 -delete

# Create new log file
touch "$LOG_DIR/app-$(date +%Y%m%d).log"
```

**Website Monitoring Script:**
```bash
#!/bin/bash
# /usr/local/bin/website-monitor.sh
WEBSITES=("https://google.com" "https://github.com" "https://your-site.com")
ALERT_EMAIL="admin@example.com"

for site in "${WEBSITES[@]}"; do
    if curl --output /dev/null --silent --head --fail --max-time 5 "$site"; then
        echo "$(date): $site is UP" >> /var/log/website-status.log
    else
        echo "$(date): $site is DOWN" >> /var/log/website-status.log
        echo "Alert: $site is down at $(date)" | mail -s "Website Down: $site" "$ALERT_EMAIL"
    fi
done
```

**Disk Space Alert Script:**
```bash
#!/bin/bash
# /usr/local/bin/disk-alert.sh
THRESHOLD=90
ALERT_EMAIL="admin@example.com"

USAGE=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')

if [ "$USAGE" -gt "$THRESHOLD" ]; then
    echo "Warning: Disk usage is at ${USAGE}%" | \
    mail -s "Disk Space Alert on $(hostname)" "$ALERT_EMAIL"
    
    # Also try to clean up
    apt clean
    journalctl --vacuum-time=7d
fi
```

---

## 10. PERFORMANCE OPTIMIZATION

### ⚡ **tuned** - Performance Tuning
```bash
# Install
sudo apt install tuned -y

# Usage
sudo systemctl start tuned
sudo systemctl enable tuned
sudo tuned-adm profile throughput-performance  # Set profile
sudo tuned-adm active                          # Show active profile
```

### 🚀 **sysctl** - Kernel Optimization
```bash
# Temporary changes
sudo sysctl -w net.core.somaxconn=65535
sudo sysctl -w vm.swappiness=10

# Permanent changes
sudo nano /etc/sysctl.conf
# Add: net.core.somaxconn=65535
# Then: sudo sysctl -p
```

### 💾 **swap** Management
```bash
# Create swap file
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile

# Make permanent
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab

# Optimize swappiness
echo 'vm.swappiness=10' | sudo tee -a /etc/sysctl.conf
sudo sysctl -p
```

### 📊 **ionice** - I/O Priority
```bash
# Run command with idle I/O priority
ionice -c3 -p $$                              # Current shell
ionice -c3 nice -n19 command                  # Command with low priority
```

### 🎯 **taskset** - CPU Affinity
```bash
# Run command on specific CPU cores
taskset -c 0,1 command                        # Use cores 0 and 1
taskset -p 1 PID                              # Set affinity for existing process
```

### 🔧 **ulimit** - Resource Limits
```bash
# Increase file descriptors
ulimit -n 65535                               # Current session
# Permanent: add to /etc/security/limits.conf
# * soft nofile 65535
# * hard nofile 65535
```

### 🗃️ **logrotate** - Log Management
```bash
# Configure
sudo nano /etc/logrotate.d/myapp

# Example config:
/var/log/myapp/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 640 root adm
    sharedscripts
    postrotate
        systemctl reload myapp > /dev/null 2>&1 || true
    endscript
}
```

### 🧹 **bleachbit** - System Cleaner
```bash
# Install
sudo apt install bleachbit -y

# Command line usage
bleachbit --list                              # List cleaners
bleachbit --clean system.cache system.tmp     # Clean specific items
bleachbit --preset                            # Clean with preset
```

---

## 11. ONE-LINE INSTALL SCRIPT

### 🚀 **Complete Additional Tools Installer**
```bash
#!/bin/bash
# Save as: install_additional_tools.sh
# Run: bash install_additional_tools.sh

echo "=== INSTALLING ADDITIONAL VPS TOOLS ==="

# Update system
sudo apt update && sudo apt upgrade -y

# PDF & Document Tools
sudo apt install -y pdftk poppler-utils ghostscript qpdf libreoffice tesseract-ocr calibre

# Image Processing Tools
sudo apt install -y imagemagick graphicsmagick gimp libimage-exiftool-perl inkscape ufraw dcraw ffmpeg pngquant jpegoptim

# Audio & Video Tools
sudo apt install -y sox handbrake-cli vlc mkvtoolnix yt-dlp

# Office & Productivity
sudo apt install -y libreoffice gnumeric pandoc texlive-latex-base texlive-latex-extra unoconv mutt

# Cloud & Sync Tools
sudo apt install -y rclone syncthing awscli megatools nextcloud-client

# Backup & Recovery
sudo apt install -y borgbackup restic duplicity rsnapshot timeshift gddrescue testdisk

# Virtualization Tools
sudo apt install -y docker.io docker-compose lxd lxc qemu-kvm libvirt-daemon-system vagrant terraform packer

# Monitoring & Alerting
sudo apt install -y prometheus grafana netdata telegraf influxdb

# Automation Tools
sudo apt install -y ansible puppet expect

# Performance Tools
sudo apt install -y tuned bleachbit

echo "=== INSTALLATION COMPLETE ==="
echo ""
echo "Installed categories:"
echo "1. 📄 PDF & Document Tools"
echo "2. 🖼️ Image Processing Tools"
echo "3. 🎵 Audio & Video Tools"
echo "4. 📊 Office & Productivity"
echo "5. ☁️ Cloud & Sync Tools"
echo "6. 💾 Backup & Recovery"
echo "7. 🐳 Virtualization Tools"
echo "8. 📊 Monitoring & Alerting"
echo "9. 🤖 Automation Tools"
echo "10. ⚡ Performance Tools"
echo ""
echo "Next steps:"
echo "1. Configure backups: sudo borg init /backup/repo"
echo "2. Set up monitoring: sudo systemctl start prometheus"
echo "3. Configure cloud sync: rclone config"
echo "4. Set up automation: ansible --version"
echo ""
echo "Log out and back in for Docker group changes."
```

### 📦 **Quick Install by Category**

**PDF & Document Tools Only:**
```bash
sudo apt install -y pdftk poppler-utils ghostscript qpdf libreoffice tesseract-ocr
```

**Image Processing Only:**
```bash
sudo apt install -y imagemagick graphicsmagick gimp libimage-exiftool-perl ffmpeg
```

**Media Tools Only:**
```bash
sudo apt install -y ffmpeg handbrake-cli vlc yt-dlp sox
```

**Cloud & Backup Only:**
```bash
sudo apt install -y rclone borgbackup restic awscli
```

**Automation Only:**
```bash
sudo apt install -y ansible terraform packer docker.io docker-compose
```

---

## 12. USEFUL CONFIGURATION SCRIPTS

### 🖥️ **VPS Optimization Script**
```bash
#!/bin/bash
# vps-optimize.sh
echo "Optimizing VPS performance..."

# Update system
sudo apt update && sudo apt upgrade -y

# Install performance tools
sudo apt install -y tuned sysstat iotop

# Configure tuned
sudo systemctl start tuned
sudo systemctl enable tuned
sudo tuned-adm profile virtual-guest

# Optimize kernel parameters
cat >> /etc/sysctl.conf << EOF
# Performance optimizations
net.core.somaxconn = 65535
net.ipv4.tcp_max_syn_backlog = 65535
net.core.netdev_max_backlog = 65535
vm.swappiness = 10
vm.vfs_cache_pressure = 50
EOF

sudo sysctl -p

# Create swap if needed
if [ ! -f /swapfile ]; then
    sudo fallocate -l 2G /swapfile
    sudo chmod 600 /swapfile
    sudo mkswap /swapfile
    sudo swapon /swapfile
    echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
fi

# Increase file limits
cat >> /etc/security/limits.conf << EOF
* soft nofile 65535
* hard