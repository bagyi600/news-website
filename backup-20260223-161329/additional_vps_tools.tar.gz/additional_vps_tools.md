# 🛠️ ADDITIONAL USEFUL VPS TOOLS & SCRIPTS
## PDF Readers, Image Tools, Productivity Utilities & More

## 📋 TABLE OF CONTENTS

1. **PDF & DOCUMENT TOOLS** - Page 2
2. **IMAGE PROCESSING TOOLS** - Page 3  
3. **AUDIO & VIDEO TOOLS** - Page 4
4. **OFFICE & PRODUCTIVITY** - Page 5
5. **CLOUD & SYNC TOOLS** - Page 6
6. **BACKUP & RECOVERY** - Page 7
7. **VIRTUALIZATION TOOLS** - Page 8
8. **MONITORING & ALERTING** - Page 9
9. **AUTOMATION SCRIPTS** - Page 10
10. **PERFORMANCE OPTIMIZATION** - Page 11
11. **ONE-LINE INSTALL SCRIPT** - Page 12

---

## 1. PDF & DOCUMENT TOOLS

### 📄 **pdftk** - PDF Toolkit
```bash
# Install
sudo apt install pdftk -y

# Usage
pdftk file1.pdf file2.pdf cat output combined.pdf  # Merge PDFs
pdftk input.pdf burst                             # Split PDF into pages
pdftk input.pdf cat 1-5 output first5.pdf         # Extract pages 1-5
pdftk input.pdf dump_data output info.txt         # Extract metadata
pdftk input.pdf background watermark.pdf output watermarked.pdf
```

### 🔍 **poppler-utils** - PDF Utilities
```bash
# Install
sudo apt install poppler-utils -y

# Includes:
pdfimages input.pdf output_prefix                # Extract images from PDF
pdfinfo input.pdf                                # PDF information
pdftoppm input.pdf output -png                   # Convert PDF to PNG
pdftotext input.pdf output.txt                   # Extract text
pdftohtml input.pdf output.html                  # Convert to HTML
```

### 🖨️ **ghostscript** - PostScript/PDF Interpreter
```bash
# Install
sudo apt install ghostscript -y

# Usage
gs -sDEVICE=pdfwrite -dNOPAUSE -dBATCH -dSAFER -sOutputFile=output.pdf input.ps
gs -sDEVICE=png16m -dNOPAUSE -dBATCH -dSAFER -sOutputFile=page-%d.png input.pdf
gs -dNOPAUSE -dBATCH -sDEVICE=pdfwrite -sOutputFile=compressed.pdf -dPDFSETTINGS=/ebook input.pdf
```

### 📊 **qpdf** - PDF Transformation Tool
```bash
# Install
sudo apt install qpdf -y

# Usage
qpdf --linearize input.pdf output.pdf            # Linearize for web
qpdf --encrypt user-password owner-password 128 -- input.pdf output.pdf
qpdf --decrypt encrypted.pdf decrypted.pdf       # Remove encryption
qpdf --pages input.pdf 1-5 -- output.pdf         # Extract pages
```

### 📝 **libreoffice** - Office Suite (Can handle PDFs)
```bash
# Install
sudo apt install libreoffice -y

# Convert documents to PDF
libreoffice --headless --convert-to pdf document.docx
libreoffice --headless --convert-to pdf *.docx    # Batch convert
```

### 🔤 **tesseract-ocr** - OCR Engine
```bash
# Install
sudo apt install tesseract-ocr tesseract-ocr-eng -y

# Usage
tesseract image.png output                      # OCR image to text
tesseract scanned.pdf output -l eng             # OCR PDF
tesseract input.png output pdf                  # OCR to PDF
```

### 📚 **calibre** - E-book Management
```bash
# Install
sudo apt install calibre -y

# Usage
ebook-convert input.epub output.pdf            # Convert EPUB to PDF
ebook-meta book.epub --get-cover cover.jpg     # Extract cover
calibre-server --port 8080 --with-library /path/to/library  # Web server
```

---

## 2. IMAGE PROCESSING TOOLS

### 🖼️ **imagemagick** - Image Manipulation
```bash
# Install
sudo apt install imagemagick -y

# Usage
convert input.jpg -resize 800x600 output.jpg    # Resize
convert input.jpg -quality 85 output.jpg        # Compress
convert input.jpg -rotate 90 output.jpg         # Rotate
convert *.jpg output.pdf                        # Convert images to PDF
convert input.pdf output.jpg                    # Convert PDF to images
convert -delay 20 -loop 0 *.png animation.gif   # Create GIF
```

### 📸 **graphicsmagick** - Faster Image Processing
```bash
# Install
sudo apt install graphicsmagick -y

# Usage
gm convert input.jpg -resize 800x600 output.jpg
gm mogrify -resize 800x600 *.jpg                # Batch resize
gm identify image.jpg                           # Image information
gm montage *.jpg -tile 3x3 -geometry +5+5 montage.jpg
```

### 🎨 **gimp** - Advanced Image Editor
```bash
# Install
sudo apt install gimp -y

# Command line usage
gimp -i -b '(gimp-file-load RUN-NONINTERACTIVE "input.jpg" "input.jpg")' -b '(gimp-file-save RUN-NONINTERACTIVE 1 (car (gimp-image-merge-visible-layers 0)) "output.png" "output.png")' -b '(gimp-quit 0)'
```

### 🔍 **exiftool** - Metadata Editor
```bash
# Install
sudo apt install libimage-exiftool-perl -y

# Usage
exiftool image.jpg                             # View metadata
exiftool -all= image.jpg                       # Remove all metadata
exiftool -GPSLatitude= -GPSLongitude= image.jpg # Remove GPS data
exiftool -Artist="Your Name" image.jpg         # Add metadata
exiftool -r -ext jpg -d %Y/%m "-directory<DateTimeOriginal" photos/ # Organize by date
```

### 🖌️ **inkscape** - Vector Graphics
```bash
# Install
sudo apt install inkscape -y

# Command line usage
inkscape input.svg --export-png=output.png --export-width=800
inkscape --export-type=pdf input.svg           # Export to PDF
inkscape --export-text-to-path input.svg       # Convert text to paths
```

### 📷 **ufraw** / **dcraw** - RAW Image Processing
```bash
# Install
sudo apt install ufraw dcraw -y

# Usage
dcraw -w -T image.cr2                         # Convert RAW to TIFF
ufraw-batch --out-type=jpg --compression=95 *.cr2 # Batch convert RAW
```

### 🎞️ **ffmpeg** - Video/Image Processing
```bash
# Install
sudo apt install ffmpeg -y

# Image operations
ffmpeg -i input.jpg -vf scale=800:600 output.jpg
ffmpeg -pattern_type glob -i '*.jpg' -c:v libx264 output.mp4 # Create video from images
ffmpeg -i video.mp4 -vf fps=1/60 thumb%04d.jpg              # Extract frames
```

### 🔄 **pngquant** / **jpegoptim** - Image Optimization
```bash
# Install
sudo apt install pngquant jpegoptim -y

# Usage
pngquant --quality=65-80 input.png            # Optimize PNG
jpegoptim --max=85 --strip-all image.jpg      # Optimize JPEG
find . -name "*.jpg" -exec jpegoptim {} \;    # Batch optimize
```

---

## 3. AUDIO & VIDEO TOOLS

### 🎵 **sox** - Audio Processing
```bash
# Install
sudo apt install sox -y

# Usage
sox input.wav output.mp3                      # Convert format
sox input.wav output.wav trim 0 30            # Trim to 30 seconds
sox input1.wav input2.wav output.wav          # Concatenate
sox input.wav output.wav reverse              # Reverse audio
sox input.wav output.wav tempo 1.5            # Change speed
```

### 🎬 **handbrake-cli** - Video Transcoding
```bash
# Install
sudo apt install handbrake-cli -y

# Usage
HandBrakeCLI -i input.mp4 -o output.mp4 -e x264 -q 20
HandBrakeCLI -i input.mkv -o output.mp4 --preset="Fast 1080p30"
HandBrakeCLI -i input.mp4 -o output.mp4 --width 1280 --height 720
```

### 📹 **vlc** - Media Player
```bash
# Install
sudo apt install vlc -y

# Command line usage
vlc --intf dummy input.mp4 --sout="#transcode{vcodec=h264,acodec=mp3}:std{access=file,mux=mp4,dst=output.mp4}" vlc://quit
cvlc -vvv input.mp4 --sout="#transcode{vcodec=theo,vb=800,scale=1,acodec=vorb,ab=128,channels=2,samplerate=44100}:http{mux=ogg,dst=:8080/}" # Stream
```

### 🎤 **audacity** - Audio Editor
```bash
# Install
sudo apt install audacity -y

# Note: Primarily GUI, but can be scripted with mod-script-pipe
```

### 🎞️ **mkvtoolnix** - MKV Manipulation
```bash
# Install
sudo apt install mkvtoolnix -y

# Usage
mkvmerge -o output.mkv input1.mkv + input2.mkv # Merge
mkvextract tracks input.mkv 2:subtitles.srt    # Extract subtitles
mkvpropedit input.mkv --edit track:a1 --set language=eng # Set language
```

### 📼 **youtube-dl** / **yt-dlp** - Video Downloader
```bash
# Install yt-dlp (better maintained)
sudo apt install yt-dlp -y

# Usage
yt-dlp https://youtube.com/watch?v=VIDEO_ID    # Download video
yt-dlp -x --audio-format mp3 URL               # Audio only
yt-dlp -f bestvideo+bestaudio URL              # Best quality
yt-dlp --list-formats URL                      # List available formats
```

---

## 4. OFFICE & PRODUCTIVITY

### 📊 **libreoffice** - Full Office Suite
```bash
# Install full suite
sudo apt install libreoffice libreoffice-writer libreoffice-calc libreoffice-impress libreoffice-draw -y

# Command line conversions
libreoffice --headless --convert-to pdf document.docx
libreoffice --headless --convert-to html spreadsheet.ods
libreoffice --headless --convert-to txt presentation.ppt

# Batch processing
for file in *.docx; do libreoffice --headless --convert-to pdf "$file"; done
```

### 📈 **gnumeric** / **ssconvert** - Spreadsheet Tools
```bash
# Install
sudo apt install gnumeric -y

# Usage
ssconvert spreadsheet.xlsx output.csv          # Convert to CSV
ssconvert input.ods output.xlsx                # Convert formats
ssconvert -S input.xlsx output.csv             # Convert all sheets
```

### 📋 **pandoc** - Document Converter
```bash
# Install
sudo apt install pandoc -y

# Usage
pandoc input.md -o output.pdf                  # Markdown to PDF
pandoc input.docx -o output.html               # DOCX to HTML
pandoc -s input.tex -o output.docx             # LaTeX to DOCX
pandoc -f markdown -t latex -o output.tex input.md
```

### 📝 **texlive** - LaTeX Typesetting
```bash
# Install
sudo apt install texlive-latex-base texlive-latex-extra texlive-fonts-recommended -y

# Usage
pdflatex document.tex                          # Compile LaTeX to PDF
latexmk -pdf document.tex                      # Auto-compile with dependencies
```

### 🗂️ **unoconv** - Universal Document Converter
```bash
# Install
sudo apt install unoconv -y

# Usage
unoconv -f pdf document.docx                   # Convert to PDF
unoconv -f html spreadsheet.ods                # Convert to HTML
unoconv -f txt presentation.ppt                # Convert to text
```

### 📅 **khal** / **vdirsyncer** - Calendar & Contacts
```bash
# Install
sudo apt install khal vdirsyncer -y

# Usage
khal calendar                                  # View calendar
khal new "Meeting at 2pm tomorrow"             # Add event
vdirsyncer discover                            # Discover calendars
vdirsyncer sync                                # Sync calendars
```

### 📧 **mutt** / **alpine** - Email Clients
```bash
# Install
sudo apt install mutt alpine -y

# Usage
mutt -s "Subject" recipient@example.com < message.txt
echo "Body" | mutt -s "Subject" -a attachment.pdf recipient@example.com
```

---

## 5. CLOUD & SYNC TOOLS

### ☁️ **rclone** - Cloud Storage Sync
```bash
# Install
sudo apt install rclone -y

# Configure
rclone config                                  # Interactive setup

# Usage
rclone copy /local/path remote:bucket/path     # Copy to cloud
rclone sync /local/path remote:bucket/path     # Sync (deletes extra)
rclone mount remote:bucket/path /mnt/cloud     # Mount as filesystem
rclone ls remote:bucket                        # List files
rclone size remote:bucket                      # Show size
```

### 🔄 **syncthing** - P2P File Sync
```bash
# Install
sudo apt install syncthing -y

# Usage
systemctl --user start syncthing              # Start service
systemctl --user enable syncthing             # Enable auto-start
# Access web UI at http://localhost:8384
```

### 📤 **aws-cli** - Amazon Web Services
```bash
# Install
sudo apt install awscli -y

# Configure
aws configure                                 # Set credentials

# Usage
aws s3 cp file.txt s3://bucket/path/          # Upload to S3
aws s3 sync /local/path s3://bucket/path/     # Sync directory
aws ec2 describe-instances                    # List EC2 instances
aws s3 ls                                     # List S3 buckets
```

### 📥 **gcloud** - Google Cloud SDK
```bash
# Install
curl https://sdk.cloud.google.com | bash
exec -l $SHELL
gcloud init

# Usage
gcloud compute instances list                 # List VM instances
gcloud storage cp file.txt gs://bucket/path/  # Upload to Cloud Storage
gcloud auth login                             # Authenticate
```

### 🔗 **az** - Azure CLI
```bash
# Install
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash

# Usage
az login                                      # Authenticate
az vm list                                    # List virtual machines
az storage blob upload -f file.txt -c container -n blobname
```

### 🌐 **megatools** - Mega.nz Client
```bash
# Install
sudo apt install megatools -y

# Usage
megadf                                        # Show storage info
megals /Root                                  # List files
megaget /Root/file.txt                        # Download file
megaput file.txt                              # Upload file
```

### 🗃️ **nextcloud-client** - Nextcloud Sync
```bash
# Install
sudo apt install nextcloud-client -y

# Usage
nextcloudcmd --user user --password pass /local/path https://nextcloud.example.com
# Or use GUI for setup, then runs in background
```

---

## 6. BACKUP & RECOVERY TOOLS

### 💾 **borgbackup** - Deduplicating Backup
```bash
# Install
sudo apt install borgbackup -y

# Usage
borg init /backup/repo                        # Initialize repository
borg create /backup/repo::backup-{now} /data  # Create backup
borg list /backup/repo                        # List backups
borg extract /backup/repo::backup-name /path  # Extract backup
borg prune --keep-daily=7 --keep-weekly=4 /backup/repo # Cleanup
```

### 🗂️ **restic** - Fast, Secure Backup
```bash
# Install
sudo apt install restic -y

# Usage
restic init --repo /backup                    # Initialize
restic backup --repo /backup /data            # Backup
restic snapshots --repo /backup               # List snapshots
restic restore latest --target /restore --repo /backup # Restore
restic forget --keep-last 7 --repo /backup    # Cleanup
```

### 📦 **duplicity** / **deja-dup** - Encrypted Backup
```bash
# Install
sudo apt install duplicity deja-dup -y

# Usage
duplicity /data file:///backup                # Local backup
duplicity /data s3://bucket/path              # S3 backup
duplicity restore file:///backup /restore     # Restore
duplicity collection-status file:///backup    # Status
```

### 🗄️ **rsnapshot** - Snapshot Backup
```bash
# Install
sudo apt install rsnapshot -y

# Configuration
sudo nano /etc/rsn
