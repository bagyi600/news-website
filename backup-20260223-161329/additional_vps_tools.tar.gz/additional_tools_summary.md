# 🛠️ ADDITIONAL VPS TOOLS MASTER GUIDE
## PDF Readers, Image Tools, Media, Cloud, Backup & Automation

## 🚀 QUICK START - ESSENTIAL ADDITIONS

### **Complete Additional Tools Install**
```bash
# One command to install all additional tools:
sudo apt update && sudo apt upgrade -y && \
sudo apt install -y pdftk poppler-utils imagemagick ffmpeg libreoffice rclone borgbackup docker.io ansible prometheus grafana
```

### **Category-by-Category Installation**

**📄 PDF & Document Tools:**
```bash
sudo apt install -y pdftk poppler-utils ghostscript qpdf libreoffice tesseract-ocr
```

**🖼️ Image Processing:**
```bash
sudo apt install -y imagemagick graphicsmagick libimage-exiftool-perl ffmpeg jpegoptim
```

**🎵 Media Tools:**
```bash
sudo apt install -y ffmpeg handbrake-cli vlc yt-dlp sox
```

**☁️ Cloud & Sync:**
```bash
sudo apt install -y rclone awscli nextcloud-client
```

**💾 Backup & Recovery:**
```bash
sudo apt install -y borgbackup restic duplicity timeshift
```

**🤖 Automation:**
```bash
sudo apt install -y ansible terraform docker.io docker-compose
```

---

## 📋 CATEGORY SUMMARY

### **1. 📄 PDF & DOCUMENT TOOLS**
- **pdftk** - PDF manipulation (merge, split, encrypt)
- **poppler-utils** - PDF utilities (extract text, images, info)
- **ghostscript** - PostScript/PDF processing
- **libreoffice** - Office suite with PDF export
- **tesseract-ocr** - Optical Character Recognition
- **calibre** - E-book management and conversion

### **2. 🖼️ IMAGE PROCESSING TOOLS**
- **imagemagick** - Swiss army knife for images (convert, resize, optimize)
- **graphicsmagick** - Faster alternative to ImageMagick
- **gimp** - Advanced image editor (can batch process)
- **exiftool** - Metadata editing and viewing
- **inkscape** - Vector graphics editor
- **ffmpeg** - Video/image processing (extract frames, convert)
- **pngquant/jpegoptim** - Image optimization

### **3. 🎵 AUDIO & VIDEO TOOLS**
- **ffmpeg** - Complete media processing
- **handbrake-cli** - Video transcoding
- **vlc** - Media player with streaming capabilities
- **sox** - Audio processing and conversion
- **yt-dlp** - Video downloader (YouTube, etc.)
- **mkvtoolnix** - MKV file manipulation

### **4. 📊 OFFICE & PRODUCTIVITY**
- **libreoffice** - Complete office suite
- **pandoc** - Universal document converter
- **texlive** - LaTeX typesetting system
- **gnumeric** - Spreadsheet with conversion tools
- **mutt** - Command-line email client

### **5. ☁️ CLOUD & SYNC TOOLS**
- **rclone** - Sync to 40+ cloud services
- **aws-cli** - Amazon Web Services CLI
- **syncthing** - P2P file synchronization
- **nextcloud-client** - Nextcloud sync client
- **megatools** - Mega.nz client

### **6. 💾 BACKUP & RECOVERY**
- **borgbackup** - Deduplicating backup (efficient)
- **restic** - Fast, secure, cloud-ready backup
- **duplicity** - Encrypted incremental backup
- **timeshift** - System restore points
- **ddrescue** - Data recovery from failing drives
- **testdisk** - Partition recovery and file undelete

### **7. 🐳 VIRTUALIZATION & CONTAINERS**
- **docker** / **docker-compose** - Container platform
- **lxd** / **lxc** - System containers
- **vagrant** - Development environment management
- **terraform** - Infrastructure as code
- **packer** - Machine image creation

### **8. 📊 MONITORING & ALERTING**
- **prometheus** - Monitoring system and time series DB
- **grafana** - Visualization and dashboards
- **netdata** - Real-time performance monitoring
- **telegraf** - Metrics collector
- **influxdb** - Time series database

### **9. 🤖 AUTOMATION TOOLS**
- **ansible** - Configuration management (agentless)
- **puppet** - Configuration management
- **terraform** - Infrastructure provisioning
- **fabric** / **invoke** - Python task automation
- **expect** - Automated interactive sessions

### **10. ⚡ PERFORMANCE OPTIMIZATION**
- **tuned** - System performance profiles
- **sysctl** - Kernel parameter tuning
- **ionice** / **taskset** - Process priority and affinity
- **logrotate** - Log file management
- **bleachbit** - System cleaning

---

## 🎯 TOP 10 MOST USEFUL ADDITIONS

### **1. PDF Manipulation (pdftk)**
```bash
# Merge PDFs
pdftk file1.pdf file2.pdf cat output combined.pdf

# Split PDF
pdftk input.pdf burst

# Extract pages 1-5
pdftk input.pdf cat 1-5 output first5.pdf
```

### **2. Image Processing (imagemagick)**
```bash
# Resize image
convert input.jpg -resize 800x600 output.jpg

# Convert images to PDF
convert *.jpg output.pdf

# Create thumbnail
convert input.jpg -thumbnail 200x200 thumb.jpg
```

### **3. Media Conversion (ffmpeg)**
```bash
# Convert video format
ffmpeg -i input.mkv output.mp4

# Extract audio
ffmpeg -i video.mp4 -vn audio.mp3

# Create video from images
ffmpeg -framerate 1 -i image%03d.jpg video.mp4
```

### **4. Cloud Sync (rclone)**
```bash
# Copy to cloud
rclone copy /local/path remote:bucket/path

# Sync (mirror)
rclone sync /local/path remote:bucket/path

# Mount cloud as local
rclone mount remote:bucket/path /mnt/cloud
```

### **5. Backup (borgbackup)**
```bash
# Initialize repository
borg init /backup/repo

# Create backup
borg create /backup/repo::backup-{now} /data

# List backups
borg list /backup/repo

# Extract backup
borg extract /backup/repo::backup-name
```

### **6. Container Management (docker)**
```bash
# Run container
docker run -it ubuntu bash

# Build image
docker build -t myapp .

# Manage with compose
docker-compose up -d
```

### **7. Automation (ansible)**
```bash
# Test connectivity
ansible all -m ping

# Run playbook
ansible-playbook setup.yml

# Install role
ansible-galaxy install username.rolename
```

### **8. Monitoring (prometheus + grafana)**
```bash
# Start services
sudo systemctl start prometheus
sudo systemctl start grafana-server

# Access at:
# Prometheus: http://localhost:9090
# Grafana: http://localhost:3000 (admin/admin)
```

### **9. Document Conversion (libreoffice)**
```bash
# Convert to PDF
libreoffice --headless --convert-to pdf document.docx

# Batch convert
for file in *.docx; do libreoffice --headless --convert-to pdf "$file"; done
```

### **10. System Optimization (tuned)**
```bash
# Activate profile
sudo tuned-adm profile virtual-guest

# List profiles
sudo tuned-adm list

# Show active
sudo tuned-adm active
```

---

## 🛠️ READY-TO-USE SCRIPTS

### **Automated Backup Script**
```bash
#!/bin/bash
# auto-backup.sh
BACKUP_DIR="/backup"
SOURCE_DIRS=("/home" "/etc" "/var/www")
DATE=$(date +%Y%m%d_%H%M%S)

echo "Starting backup at $(date)"

# Create backup
tar -czf "$BACKUP_DIR/backup-$DATE.tar.gz" "${SOURCE_DIRS[@]}"

# Encrypt (optional)
# gpg --encrypt --recipient "Your Name" "$BACKUP_DIR/backup-$DATE.tar.gz"

# Upload to cloud (if rclone configured)
# rclone copy "$BACKUP_DIR/backup-$DATE.tar.gz" remote:backups/

# Clean old backups (keep 30 days)
find "$BACKUP_DIR" -name "backup-*.tar.gz" -mtime +30 -delete

echo "Backup completed at $(date)"
```

### **Image Optimization Script**
```bash
#!/bin/bash
# optimize-images.sh
QUALITY=85
MAX_WIDTH=1920

echo "Optimizing images in $(pwd)"

# Optimize JPEGs
find . -name "*.jpg" -o -name "*.jpeg" | while read file; do
    echo "Optimizing: $file"
    jpegoptim --max=$QUALITY --strip-all --all-progressive "$file"
    
    # Resize if too large
    width=$(identify -format "%w" "$file")
    if [ "$width" -gt "$MAX_WIDTH" ]; then
        convert "$file" -resize "${MAX_WIDTH}x" "$file"
    fi
done

# Optimize PNGs
find . -name "*.png" | while read file; do
    echo "Optimizing: $file"
    pngquant --quality=65-80 --force --skip-if-larger --ext .png "$file"
done

echo "Image optimization complete"
```

### **PDF Processing Script**
```bash
#!/bin/bash
# process-pdfs.sh
INPUT_DIR="./input"
OUTPUT_DIR="./output"
WATERMARK="watermark.pdf"

mkdir -p "$OUTPUT_DIR"

for pdf in "$INPUT_DIR"/*.pdf; do
    if [ -f "$pdf" ]; then
        filename=$(basename "$pdf")
        echo "Processing: $filename"
        
        # Add watermark
        pdftk "$pdf" background "$WATERMARK" output "$OUTPUT_DIR/$filename"
        
        # Linearize for web
        qpdf --linearize "$OUTPUT_DIR/$filename" "$OUTPUT_DIR/linearized-$filename"
        
        # Extract text (for search)
        pdftotext "$pdf" "$OUTPUT_DIR/${filename%.pdf}.txt"
    fi
done

echo "PDF processing complete"
```

### **Media Conversion Script**
```bash
#!/bin/bash
# convert-media.sh
INPUT_FORMAT="mkv"
OUTPUT_FORMAT="mp4"
QUALITY=23  # Lower = better quality (18-28 range)

echo "Converting .$INPUT_FORMAT to .$OUTPUT_FORMAT"

for file in *."$INPUT_FORMAT"; do
    if [ -f "$file" ]; then
        output="${file%.$INPUT_FORMAT}.$OUTPUT_FORMAT"
        echo "Converting: $file -> $output"
        
        ffmpeg -i "$file" \
            -c:v libx264 \
            -crf "$QUALITY" \
            -c:a aac \
            -b:a 128k \
            "$output"
    fi
done

echo "Conversion complete"
```

### **System Monitor Script**
```bash
#!/bin/bash
# system-monitor.sh
LOG_FILE="/var/log/system-monitor.log"
ALERT_EMAIL="admin@example.com"

echo "=== System Check at $(date) ===" >> "$LOG_FILE"

# CPU Load
LOAD=$(uptime | awk -F'load average:' '{print $2}')
echo "Load Average: $LOAD" >> "$LOG_FILE"

# Memory
MEMORY=$(free -h | awk 'NR==2 {print "Used: " $3 "/" $2 " (" $3/$2*100 "%)"}')
echo "Memory: $MEMORY" >> "$LOG_FILE"

# Disk
DISK=$(df -h / | awk 'NR==2 {print "Used: " $3 "/" $2 " (" $5 ")"}')
echo "Disk: $DISK" >> "$LOG_FILE"

# Check thresholds
DISK_PERCENT=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
if [ "$DISK_PERCENT" -gt 90 ]; then
    echo "ALERT: Disk usage above 90%" | mail -s "Disk Alert" "$ALERT_EMAIL"
fi

echo "=== Check Complete ===" >> "$LOG_FILE"
```

---

## 📥 DOWNLOAD THIS GUIDE

All tools, commands, and scripts are available at:
- `/tmp/additional_vps_tools.md` - Main guide
- `/tmp/additional_vps_tools_part2.md` - Additional content
- `/tmp/additional_tools_summary.md` - This summary

**To save this guide:**
```bash
# Copy to your home directory
cp /tmp/additional_tools_summary.md ~/vps_additional_tools.md

# Create installation script
cat > ~/install_additional_tools.sh << 'EOF'
#!/bin/bash
echo "Installing additional VPS tools..."
sudo apt update && sudo apt upgrade -y
sudo apt install -y pdftk imagemagick ffmpeg libreoffice rclone borgbackup docker.io ansible
echo "Installation complete!"
EOF
chmod +x ~/install_additional_tools.sh
```

**Quick Reference Card:**
```bash
# PDF: pdftk, poppler-utils, ghostscript
# Images: imagemagick, exiftool, ffmpeg  
# Media: ffmpeg, handbrake-cli, vlc
# Office: libreoffice, pandoc
# Cloud: rclone, aws-cli
# Backup: borgbackup, restic
# Containers: docker, docker-compose
# Automation: ansible, terraform
# Monitoring: prometheus, grafana
```

---

## 🎯 RECOMMENDED STACKS

### **For Web Developers:**
```bash
sudo apt install -y imagemagick ffmpeg libreoffice rclone docker.io docker-compose ansible
```

### **For Content Creators:**
```bash
sudo apt install -y imagemagick gimp ffmpeg handbrake-cli calibre pandoc
```

### **For System Administrators:**
```bash
sudo apt install -y ansible terraform prometheus grafana borgbackup rclone
```

### **For Data Processing:**
```bash
sudo apt install -y poppler-utils tesseract-ocr imagemagick ffmpeg pandoc
```

### **For Personal VPS:**
```bash
sudo apt install -y rclone syncthing borgbackup vlc yt-dlp libreoffice
```

---

## 💡 PRO TIPS

1. **Use Docker** for isolated tool environments
2. **Schedule backups** with cron + borgbackup
3. **Monitor** with prometheus/grafana for visibility
4. **Automate** with ansible for consistency
5. **Optimize images** before uploading to web
6. **Use rclone** for multi-cloud redundancy
7. **Test restores** regularly from backups
8. **Document** your automation scripts
9. **Version control** your infrastructure code
10. **Monitor logs** for early problem detection

---

**Remember:** Always test new tools in a safe environment before deploying to production!

---
**Created by:** Nexus AI Assistant  
**Date:** February 2026  
**For:** Enhanced VPS Productivity  
**Status:** Complete Additional Tools Guide