id="undo" class="tool-btn">↩️ Undo</button>
            <button id="redo" class="tool-btn">↪️ Redo</button>
        </div>
        
        <div class="canvas-container">
            <canvas id="drawingCanvas" width="1000" height="600"></canvas>
        </div>
        
        <div class="controls">
            <div class="control-group">
                <h3>Brush Settings</h3>
                <label>Size: <span id="brushSizeValue">5</span>px</label>
                <input type="range" id="brushSize" min="1" max="50" value="5">
                <label>Opacity: <span id="opacityValue">100</span>%</label>
                <input type="range" id="opacity" min="1" max="100" value="100">
            </div>
            
            <div class="control-group">
                <h3>Canvas Settings</h3>
                <label>Background Color:</label>
                <input type="color" id="backgroundColor" value="#ffffff">
                <button id="changeBackground" class="tool-btn">Apply</button>
                <br><br>
                <label>Canvas Size:</label>
                <select id="canvasSize">
                    <option value="800,600">800x600</option>
                    <option value="1000,600" selected>1000x600</option>
                    <option value="1200,800">1200x800</option>
                    <option value="1920,1080">1920x1080</option>
                </select>
                <button id="resizeCanvas" class="tool-btn">Resize</button>
            </div>
            
            <div class="control-group">
                <h3>Text Tool</h3>
                <input type="text" id="textInput" placeholder="Enter text" style="width: 100%; padding: 5px; margin-bottom: 10px;">
                <label>Font Size:</label>
                <input type="range" id="fontSize" min="10" max="100" value="30">
                <select id="fontFamily" style="width: 100%; padding: 5px; margin-top: 10px;">
                    <option>Arial</option>
                    <option>Times New Roman</option>
                    <option>Courier New</option>
                    <option>Georgia</option>
                    <option>Verdana</option>
                </select>
            </div>
        </div>
        
        <div class="save-options">
            <h3>Save & Export</h3>
            <button id="savePNG" class="tool-btn">💾 Save as PNG</button>
            <button id="saveJPG" class="tool-btn">🖼️ Save as JPG</button>
            <button id="saveSVG" class="tool-btn">📐 Save as SVG</button>
            <button id="print" class="tool-btn">🖨️ Print</button>
            
            <div class="preview" id="previewContainer" style="display: none;">
                <h4>Preview</h4>
                <img id="previewImage" src="" alt="Preview">
                <p><a id="downloadLink" href="#" download="canvas_art.png">Click to download</a></p>
            </div>
        </div>
    </div>

    <script>
        // Canvas setup
        const canvas = document.getElementById('drawingCanvas');
        const ctx = canvas.getContext('2d');
        
        // State management
        let currentTool = 'brush';
        let currentColor = '#000000';
        let brushSize = 5;
        let opacity = 1.0;
        let isDrawing = false;
        let lastX = 0;
        let lastY = 0;
        let history = [];
        let historyIndex = -1;
        
        // Initialize canvas
        function initCanvas() {
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            saveState();
        }
        
        // Save canvas state to history
        function saveState() {
            // Remove any future states if we're not at the end
            history = history.slice(0, historyIndex + 1);
            
            // Save current state
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            history.push(imageData);
            historyIndex++;
            
            // Limit history size
            if (history.length > 20) {
                history.shift();
                historyIndex--;
            }
        }
        
        // Undo last action
        function undo() {
            if (historyIndex > 0) {
                historyIndex--;
                const imageData = history[historyIndex];
                ctx.putImageData(imageData, 0, 0);
            }
        }
        
        // Redo last undone action
        function redo() {
            if (historyIndex < history.length - 1) {
                historyIndex++;
                const imageData = history[historyIndex];
                ctx.putImageData(imageData, 0, 0);
            }
        }
        
        // Drawing functions
        function startDrawing(e) {
            isDrawing = true;
            [lastX, lastY] = getMousePos(e);
            
            if (currentTool === 'text') {
                const text = document.getElementById('textInput').value;
                if (text) {
                    const fontSize = document.getElementById('fontSize').value;
                    const fontFamily = document.getElementById('fontFamily').value;
                    
                    ctx.font = `${fontSize}px ${fontFamily}`;
                    ctx.fillStyle = currentColor;
                    ctx.globalAlpha = opacity;
                    ctx.fillText(text, lastX, lastY);
                    ctx.globalAlpha = 1.0;
                    
                    saveState();
                }
                return;
            }
        }
        
        function draw(e) {
            if (!isDrawing) return;
            
            const [x, y] = getMousePos(e);
            
            ctx.beginPath();
            ctx.globalAlpha = opacity;
            ctx.strokeStyle = currentColor;
            ctx.fillStyle = currentColor;
            ctx.lineWidth = brushSize;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            
            switch(currentTool) {
                case 'brush':
                    ctx.beginPath();
                    ctx.moveTo(lastX, lastY);
                    ctx.lineTo(x, y);
                    ctx.stroke();
                    break;
                    
                case 'line':
                    // For line, we draw on mouse up
                    break;
                    
                case 'rectangle':
                    // For rectangle, we draw on mouse up
                    break;
                    
                case 'circle':
                    // For circle, we draw on mouse up
                    break;
                    
                case 'eraser':
                    ctx.strokeStyle = '#ffffff';
                    ctx.beginPath();
                    ctx.moveTo(lastX, lastY);
                    ctx.lineTo(x, y);
                    ctx.stroke();
                    break;
            }
            
            ctx.globalAlpha = 1.0;
            [lastX, lastY] = [x, y];
        }
        
        function stopDrawing(e) {
            if (!isDrawing) return;
            
            const [x, y] = getMousePos(e);
            
            if (currentTool === 'line') {
                ctx.beginPath();
                ctx.moveTo(lastX, lastY);
                ctx.lineTo(x, y);
                ctx.stroke();
                saveState();
            } else if (currentTool === 'rectangle') {
                const width = x - lastX;
                const height = y - lastY;
                ctx.strokeRect(lastX, lastY, width, height);
                saveState();
            } else if (currentTool === 'circle') {
                const radius = Math.sqrt(Math.pow(x - lastX, 2) + Math.pow(y - lastY, 2));
                ctx.beginPath();
                ctx.arc(lastX, lastY, radius, 0, Math.PI * 2);
                ctx.stroke();
                saveState();
            } else if (currentTool === 'brush' || currentTool === 'eraser') {
                saveState();
            }
            
            isDrawing = false;
        }
        
        // Utility functions
        function getMousePos(e) {
            const rect = canvas.getBoundingClientRect();
            return [
                e.clientX - rect.left,
                e.clientY - rect.top
            ];
        }
        
        function changeBackground() {
            const color = document.getElementById('backgroundColor').value;
            ctx.fillStyle = color;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            saveState();
        }
        
        function resizeCanvas() {
            const size = document.getElementById('canvasSize').value.split(',');
            const width = parseInt(size[0]);
            const height = parseInt(size[1]);
            
            // Save current content
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            
            // Resize canvas
            canvas.width = width;
            canvas.height = height;
            
            // Restore content
            ctx.putImageData(imageData, 0, 0);
            saveState();
        }
        
        function saveImage(format) {
            const dataUrl = canvas.toDataURL(`image/${format}`);
            const link = document.createElement('a');
            link.download = `canvas_art_${Date.now()}.${format}`;
            link.href = dataUrl;
            link.click();
            
            // Show preview
            const preview = document.getElementById('previewImage');
            const downloadLink = document.getElementById('downloadLink');
            const previewContainer = document.getElementById('previewContainer');
            
            preview.src = dataUrl;
            downloadLink.href = dataUrl;
            downloadLink.download = link.download;
            previewContainer.style.display = 'block';
        }
        
        // Event listeners
        canvas.addEventListener('mousedown', startDrawing);
        canvas.addEventListener('mousemove', draw);
        canvas.addEventListener('mouseup', stopDrawing);
        canvas.addEventListener('mouseout', stopDrawing);
        
        // Tool selection
        document.querySelectorAll('.tool-btn[data-tool]').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.tool-btn[data-tool]').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                currentTool = this.dataset.tool;
            });
        });
        
        // Color selection
        document.querySelectorAll('.color').forEach(colorBtn => {
            colorBtn.addEventListener('click', function() {
                document.querySelectorAll('.color').forEach(c => c.classList.remove('active'));
                this.classList.add('active');
                currentColor = this.dataset.color;
            });
        });
        
        // Brush size
        const brushSizeSlider = document.getElementById('brushSize');
        const brushSizeValue = document.getElementById('brushSizeValue');
        brushSizeSlider.addEventListener('input', function() {
            brushSize = this.value;
            brushSizeValue.textContent = brushSize;
        });
        
        // Opacity
        const opacitySlider = document.getElementById('opacity');
        const opacityValue = document.getElementById('opacityValue');
        opacitySlider.addEventListener('input', function() {
            opacity = this.value / 100;
            opacityValue.textContent = this.value;
        });
        
        // Controls
        document.getElementById('clear').addEventListener('click', () => {
            if (confirm('Clear the canvas?')) {
                ctx.fillStyle = '#ffffff';
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                saveState();
            }
        });
        
        document.getElementById('undo').addEventListener('click', undo);
        document.getElementById('redo').addEventListener('click', redo);
        document.getElementById('changeBackground').addEventListener('click', changeBackground);
        document.getElementById('resizeCanvas').addEventListener('click', resizeCanvas);
        
        // Save buttons
        document.getElementById('savePNG').addEventListener('click', () => saveImage('png'));
        document.getElementById('saveJPG').addEventListener('click', () => saveImage('jpeg'));
        document.getElementById('saveSVG').addEventListener('click', () => {
            alert('SVG export requires additional libraries. PNG/JPG recommended.');
        });
        document.getElementById('print').addEventListener('click', () => window.print());
        
        // Initialize
        initCanvas();
        console.log('Canvas drawing tool loaded!');
    </script>
</body>
</html>
EOF

### **🤖 AUTOMATION & WORKFLOW SCRIPTS**

**1. Complete Workflow Automation Engine**
```bash
cat > /usr/local/bin/workflow_engine.py << 'EOF'
#!/usr/bin/env python3
"""
Complete Workflow Automation Engine
Chain multiple tools together for automated workflows
"""

import subprocess
import json
import os
import sys
import time
from pathlib import Path
from datetime import datetime

class WorkflowEngine:
    def __init__(self):
        self.workflows = {}
        self.load_workflows()
    
    def load_workflows(self):
        """Load predefined workflows"""
        self.workflows = {
            'research_paper': {
                'name': 'Research Paper Generator',
                'steps': [
                    {'tool': 'search', 'params': {'query': '{{topic}} latest research', 'engine': 'ddgs'}},
                    {'tool': 'pdf', 'params': {'action': 'create_from_text', 'text': '{{search_results}}', 'title': 'Research on {{topic}}'}},
                    {'tool': 'image', 'params': {'action': 'create_collage', 'images': '{{extracted_images}}', 'output': 'research_collage.png'}},
                    {'tool': 'combine', 'params': {'pdfs': ['research.pdf', 'collage.pdf'], 'output': 'final_research.pdf'}}
                ],
                'description': 'Search, compile, and create research paper'
            },
            'social_media': {
                'name': 'Social Media Content Creator',
                'steps': [
                    {'tool': 'search', 'params': {'query': '{{topic}} trending', 'max_results': 5}},
                    {'tool': 'image', 'params': {'action': 'create_text_image', 'text': '{{quote}}', 'output': 'social_post.png'}},
                    {'tool': 'image', 'params': {'action': 'apply_filters', 'input': 'social_post.png', 'filters': ['enhance', 'vignette']}},
                    {'tool': 'pdf', 'params': {'action': 'create_from_images', 'images': ['social_post_filtered.png'], 'title': 'Social Media Post'}}
                ],
                'description': 'Create social media posts with images and text'
            },
            'document_archive': {
                'name': 'Document Archive System',
                'steps': [
                    {'tool': 'pdf', 'params': {'action': 'merge', 'files': '{{input_files}}', 'output': 'archive.pdf'}},
                    {'tool': 'pdf', 'params': {'action': 'add_watermark', 'text': 'ARCHIVED {{date}}', 'output': 'archive_watermarked.pdf'}},
                    {'tool': 'pdf', 'params': {'action': 'extract_text', 'output': 'archive_text.txt'}},
                    {'tool': 'search', 'params': {'query': 'archive index', 'action': 'index', 'file': 'archive_text.txt'}}
                ],
                'description': 'Archive and index multiple documents'
            }
        }
    
    def run_tool(self, tool_name, params):
        """Run a specific tool with parameters"""
        print(f"  Running tool: {tool_name}")
        print(f"  Parameters: {params}")
        
        # This is a simplified version - in reality, you would call the actual tools
        # For now, we'll simulate the tool execution
        
        if tool_name == 'search':
            # Simulate search
            query = params.get('query', '').replace('{{topic}}', params.get('topic', 'default'))
            print(f"    Searching for: {query}")
            return {'results': [f'Result 1 for {query}', f'Result 2 for {query}']}
        
        elif tool_name == 'pdf':
            action = params.get('action', '')
            print(f"    PDF action: {action}")
            return {'output_file': f'output_{action}.pdf', 'status': 'success'}
        
        elif tool_name == 'image':
            action = params.get('action', '')
            print(f"    Image action: {action}")
            return {'output_file': f'output_{action}.png', 'status': 'success'}
        
        elif tool_name == 'combine':
            print(f"    Combining files")
            return {'output_file': 'combined_output.pdf', 'status': 'success'}
        
        return {'status': 'unknown_tool'}
    
    def run_workflow(self, workflow_name, variables=None):
        """Run a complete workflow"""
        if workflow_name not in self.workflows:
            print(f"Workflow '{workflow_name}' not found")
            return False
        
        workflow = self.workflows[workflow_name]
        print(f"🚀 Starting workflow: {workflow['name']}")
        print(f"📝 Description: {workflow['description']}")
        print(f"🔧 Steps: {len(workflow['steps'])}")
        print("-" * 50)
        
        if variables is None:
            variables = {}
        
        results = {}
        for i, step in enumerate(workflow['steps'], 1):
            print(f"\nStep {i}/{len(workflow['steps'])}")
            
            # Replace variables in parameters
            step_params = step['params'].copy()
            for key, value in step_params.items():
                if isinstance(value, str):
                    for var_name, var_value in variables.items():
                        placeholder = f'{{{{{var_name}}}}}'
                        if placeholder in value:
                            step_params[key] = value.replace(placeholder, str(var_value))
            
            # Run the tool
            tool_result = self.run_tool(step['tool'], step_params)
            results[f'step_{i}'] = tool_result
            
            # Add delay between steps (simulate processing time)
            time.sleep(1)
        
        print("\n" + "=" * 50)
        print(f"✅ Workflow '{workflow_name}' completed!")
        print(f"📊 Results: {len(results)} steps executed")
        
        # Save workflow results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"workflow_{workflow_name}_{