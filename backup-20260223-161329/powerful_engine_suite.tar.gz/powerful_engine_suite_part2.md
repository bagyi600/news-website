1):
                    text = page.extract_text()
                    if not text:
                        continue
                    
                    if not case_sensitive:
                        text = text.lower()
                        search_terms = [term.lower() for term in search_terms]
                    
                    for term in search_terms:
                        if term in text:
                            # Find context around the term
                            idx = text.find(term)
                            start = max(0, idx - 50)
                            end = min(len(text), idx + len(term) + 50)
                            context = text[start:end].replace('\n', ' ')
                            
                            results.append({
                                'file': pdf_path,
                                'page': page_num,
                                'term': term,
                                'context': context,
                                'score': text.count(term)  # Frequency
                            })
        except Exception as e:
            results.append({'file': pdf_path, 'error': str(e)})
        
        return results
    
    def search_directory(self, directory, search_terms, recursive=True):
        """Search all PDFs in a directory"""
        all_results = []
        path = Path(directory)
        
        if recursive:
            pdf_files = list(path.rglob('*.pdf'))
        else:
            pdf_files = list(path.glob('*.pdf'))
        
        print(f"Found {len(pdf_files)} PDF files to search...")
        
        for pdf_file in pdf_files:
            results = self.search_in_pdf(str(pdf_file), search_terms)
            all_results.extend(results)
        
        # Sort by score (frequency)
        all_results.sort(key=lambda x: x.get('score', 0), reverse=True)
        return all_results

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='PDF Search Engine')
    parser.add_argument('search_terms', nargs='+', help='Terms to search for')
    parser.add_argument('--directory', default='.', help='Directory to search')
    parser.add_argument('--recursive', action='store_true', help='Search recursively')
    parser.add_argument('--output', help='Output JSON file')
    
    args = parser.parse_args()
    engine = PDFSearchEngine()
    
    results = engine.search_directory(args.directory, args.search_terms, args.recursive)
    
    # Display results
    print(f"\nFound {len(results)} matches:")
    for result in results[:20]:  # Show top 20
        if 'error' in result:
            print(f"ERROR in {result['file']}: {result['error']}")
        else:
            print(f"\n📄 {result['file']} (Page {result['page']})")
            print(f"   Term: '{result['term']}' (Score: {result['score']})")
            print(f"   Context: ...{result['context']}...")
    
    if args.output:
        import json
        with open(args.output, 'w') as f:
            json.dump(results, f, indent=2)
        print(f"\nFull results saved to {args.output}")
EOF
chmod +x /usr/local/bin/pdf_search.py

### **🖼️ ADVANCED PHOTO CREATION & EDITING TOOLS**

**1. Image Processing Engine Installation**
```bash
# Install comprehensive image tools
sudo apt install -y imagemagick graphicsmagick gimp inkscape ffmpeg libimage-exiftool-perl
pip3 install Pillow opencv-python numpy scikit-image matplotlib
```

**2. Advanced Photo Creation Engine**
```bash
cat > /usr/local/bin/photo_engine.py << 'EOF'
#!/usr/bin/env python3
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
import numpy as np
import cv2
import argparse
import os
from pathlib import Path
import random
from datetime import datetime

class PhotoEngine:
    def __init__(self):
        self.fonts = self._load_fonts()
    
    def _load_fonts(self):
        """Load available fonts"""
        fonts = {}
        font_dirs = [
            '/usr/share/fonts/truetype/dejavu/',
            '/usr/share/fonts/truetype/liberation/',
            '/usr/share/fonts/opentype/',
        ]
        
        for font_dir in font_dirs:
            if os.path.exists(font_dir):
                for root, dirs, files in os.walk(font_dir):
                    for file in files:
                        if file.endswith(('.ttf', '.otf')):
                            font_path = os.path.join(root, file)
                            fonts[file] = font_path
        
        # Add default font
        if not fonts:
            fonts['default'] = None
        
        return fonts
    
    def create_canvas(self, width=1920, height=1080, color='white', output='canvas.png'):
        """Create a blank canvas"""
        if isinstance(color, str):
            if color == 'random':
                color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
            else:
                # Convert color name to RGB
                color_map = {
                    'white': (255, 255, 255),
                    'black': (0, 0, 0),
                    'red': (255, 0, 0),
                    'green': (0, 255, 0),
                    'blue': (0, 0, 255),
                    'gray': (128, 128, 128),
                }
                color = color_map.get(color, (255, 255, 255))
        
        img = Image.new('RGB', (width, height), color)
        img.save(output)
        return f"Created canvas: {output} ({width}x{height})"
    
    def generate_abstract_art(self, width=1920, height=1080, output='abstract.png'):
        """Generate abstract art"""
        img = Image.new('RGB', (width, height), (0, 0, 0))
        draw = ImageDraw.Draw(img)
        
        # Draw random shapes
        for _ in range(50):
            x1 = random.randint(0, width)
            y1 = random.randint(0, height)
            x2 = random.randint(x1, width)
            y2 = random.randint(y1, height)
            
            color = (
                random.randint(0, 255),
                random.randint(0, 255),
                random.randint(0, 255)
            )
            
            shape_type = random.choice(['rectangle', 'ellipse', 'line'])
            
            if shape_type == 'rectangle':
                draw.rectangle([x1, y1, x2, y2], fill=color, outline=None)
            elif shape_type == 'ellipse':
                draw.ellipse([x1, y1, x2, y2], fill=color, outline=None)
            else:  # line
                draw.line([x1, y1, x2, y2], fill=color, width=random.randint(1, 5))
        
        # Add some random text
        if self.fonts:
            font_name = random.choice(list(self.fonts.keys()))
            try:
                font = ImageFont.truetype(self.fonts[font_name], random.randint(20, 60))
                text = random.choice(['ART', 'CREATE', 'DESIGN', 'INSPIRE', 'DREAM'])
                text_color = (random.randint(200, 255), random.randint(200, 255), random.randint(200, 255))
                draw.text((random.randint(50, width-200), random.randint(50, height-100)), 
                         text, fill=text_color, font=font)
            except:
                pass
        
        img.save(output)
        return f"Generated abstract art: {output}"
    
    def create_text_image(self, text, width=800, height=400, bg_color='black', 
                         text_color='white', font_size=40, output='text_image.png'):
        """Create image with text"""
        # Create image
        img = Image.new('RGB', (width, height), bg_color)
        draw = ImageDraw.Draw(img)
        
        # Try to load a font
        font = None
        if self.fonts:
            try:
                font_name = list(self.fonts.keys())[0]
                font = ImageFont.truetype(self.fonts[font_name], font_size)
            except:
                font = ImageFont.load_default()
        else:
            font = ImageFont.load_default()
        
        # Calculate text position (centered)
        bbox = draw.textbbox((0, 0), text, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        
        x = (width - text_width) // 2
        y = (height - text_height) // 2
        
        # Draw text
        draw.text((x, y), text, fill=text_color, font=font)
        
        # Add some effects
        img = img.filter(ImageFilter.SMOOTH)
        
        img.save(output)
        return f"Created text image: {output}"
    
    def apply_filters(self, input_image, output='filtered.png', filters=None):
        """Apply multiple filters to an image"""
        img = Image.open(input_image)
        
        if filters is None:
            filters = ['enhance', 'blur', 'sharpen']
        
        for filter_name in filters:
            if filter_name == 'grayscale':
                img = img.convert('L').convert('RGB')
            elif filter_name == 'sepia':
                # Apply sepia tone
                width, height = img.size
                pixels = img.load()
                for py in range(height):
                    for px in range(width):
                        r, g, b = img.getpixel((px, py))
                        tr = int(0.393 * r + 0.769 * g + 0.189 * b)
                        tg = int(0.349 * r + 0.686 * g + 0.168 * b)
                        tb = int(0.272 * r + 0.534 * g + 0.131 * b)
                        pixels[px, py] = (min(255, tr), min(255, tg), min(255, tb))
            elif filter_name == 'blur':
                img = img.filter(ImageFilter.BLUR)
            elif filter_name == 'sharpen':
                img = img.filter(ImageFilter.SHARPEN)
            elif filter_name == 'enhance':
                enhancer = ImageEnhance.Contrast(img)
                img = enhancer.enhance(1.5)
                enhancer = ImageEnhance.Color(img)
                img = enhancer.enhance(1.2)
            elif filter_name == 'edges':
                img = img.filter(ImageFilter.FIND_EDGES)
        
        img.save(output)
        return f"Applied filters: {output}"
    
    def create_collage(self, image_files, output='collage.png', cols=3, width=1200):
        """Create photo collage"""
        if not image_files:
            return "No images provided"
        
        # Open all images
        images = []
        for img_file in image_files:
            try:
                img = Image.open(img_file)
                images.append(img)
            except:
                continue
        
        if not images:
            return "Could not open any images"
        
        # Calculate layout
        rows = (len(images) + cols - 1) // cols
        thumb_width = width // cols
        thumb_height = thumb_width  # Square thumbnails
        
        # Create collage canvas
        collage = Image.new('RGB', (width, rows * thumb_height), (240, 240, 240))
        
        # Paste images
        for i, img in enumerate(images):
            # Resize image
            img.thumbnail((thumb_width, thumb_height))
            
            # Calculate position
            row = i // cols
            col = i % cols
            x = col * thumb_width
            y = row * thumb_height
            
            # Paste image
            collage.paste(img, (x, y))
        
        collage.save(output)
        return f"Created collage with {len(images)} images: {output}"
    
    def generate_pattern(self, pattern_type='checkerboard', size=100, output='pattern.png'):
        """Generate patterns"""
        img = Image.new('RGB', (size*10, size*10), (255, 255, 255))
        draw = ImageDraw.Draw(img)
        
        if pattern_type == 'checkerboard':
            for i in range(10):
                for j in range(10):
                    color = (0, 0, 0) if (i + j) % 2 == 0 else (255, 255, 255)
                    draw.rectangle([i*size, j*size, (i+1)*size, (j+1)*size], fill=color)
        
        elif pattern_type == 'dots':
            for i in range(10):
                for j in range(10):
                    radius = size // 3
                    x = i*size + size//2
                    y = j*size + size//2
                    color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
                    draw.ellipse([x-radius, y-radius, x+radius, y+radius], fill=color)
        
        elif pattern_type == 'lines':
            for i in range(10):
                color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
                draw.line([0, i*size, 10*size, i*size], fill=color, width=size//10)
        
        img.save(output)
        return f"Generated {pattern_type} pattern: {output}"

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Advanced Photo Engine')
    subparsers = parser.add_subparsers(dest='command', help='Command to execute')
    
    # Canvas command
    canvas_parser = subparsers.add_parser('canvas', help='Create blank canvas')
    canvas_parser.add_argument('--width', type=int, default=1920)
    canvas_parser.add_argument('--height', type=int, default=1080)
    canvas_parser.add_argument('--color', default='white')
    canvas_parser.add_argument('--output', default='canvas.png')
    
    # Abstract art command
    art_parser = subparsers.add_parser('abstract', help='Generate abstract art')
    art_parser.add_argument('--width', type=int, default=1920)
    art_parser.add_argument('--height', type=int, default=1080)
    art_parser.add_argument('--output', default='abstract.png')
    
    # Text image command
    text_parser = subparsers.add_parser('text', help='Create text image')
    text_parser.add_argument('text', help='Text to display')
    text_parser.add_argument('--width', type=int, default=800)
    text_parser.add_argument('--height', type=int, default=400)
    text_parser.add_argument('--bg-color', default='black')
    text_parser.add_argument('--text-color', default='white')
    text_parser.add_argument('--font-size', type=int, default=40)
    text_parser.add_argument('--output', default='text_image.png')
    
    # Filters command
    filter_parser = subparsers.add_parser('filter', help='Apply filters')
    filter_parser.add_argument('input_image', help='Input image')
    filter_parser.add_argument('--filters', nargs='+', default=['enhance', 'blur'])
    filter_parser.add_argument('--output', default='filtered.png')
    
    # Collage command
    collage_parser = subparsers.add_parser('collage', help='Create collage')
    collage_parser.add_argument('image_files', nargs='+', help='Input images')
    collage_parser.add_argument('--cols', type=int, default=3)
    collage_parser.add_argument('--width', type=int, default=1200)
    collage_parser.add_argument('--output', default='collage.png')
    
    # Pattern command
    pattern_parser = subparsers.add_parser('pattern', help='Generate pattern')
    pattern_parser.add_argument('--type', choices=['checkerboard', 'dots', 'lines'], default='checkerboard')
    pattern_parser.add_argument('--size', type=int, default=100)
    pattern_parser.add_argument('--output', default='pattern.png')
    
    args = parser.parse_args()
    engine = PhotoEngine()
    
    if args.command == 'canvas':
        result = engine.create_canvas(args.width, args.height, args.color, args.output)
    elif args.command == 'abstract':
        result = engine.generate_abstract_art(args.width, args.height, args.output)
    elif args.command == 'text':
        result = engine.create_text_image(args.text, args.width, args.height, 
                                         args.bg_color, args.text_color, 
                                         args.font_size, args.output)
    elif args.command == 'filter':
        result = engine.apply_filters(args.input_image, args.output, args.filters)
    elif args.command == 'collage':
        result = engine.create_collage(args.image_files, args.output, args.cols, args.width)
    elif args.command == 'pattern':
        result = engine.generate_pattern(args.type, args.size, args.output)
    else:
        parser.print_help()
        result = "No command specified"
    
    print(result)
EOF
chmod +x /usr/local/bin/photo_engine.py
```

**3. AI-Powered Image Generator (Using Stable Diffusion-like approach)**
```bash
cat > /usr/local/bin/ai_image_generator.py << 'EOF'
#!/usr/bin/env python3
"""
AI Image Generator using deep learning models
Note: This requires torch and diffusers packages
Install with: pip3 install torch diffusers transformers pillow
"""

import argparse
import os
from pathlib import Path

try:
    import torch
    from diffusers import StableDiffusionPipeline
    from PIL import Image
    HAS_AI = True
except ImportError:
    HAS_AI = False

class AIImageGenerator:
    def __init__(self, model_id="runwayml/stable-diffusion-v1-5"):
        self.model_id = model_id
        self.pipe = None
        
        if not