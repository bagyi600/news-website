# 🖥️ COMPLETE VPS TERMINAL TOOLS GUIDE
## Essential Tools, Dependencies & Installation Commands

## 📋 TABLE OF CONTENTS

1. **SYSTEM MONITORING TOOLS** - Page 2
2. **NETWORK TOOLS** - Page 3
3. **SECURITY TOOLS** - Page 4
4. **DEVELOPMENT TOOLS** - Page 5
5. **FILE MANAGEMENT TOOLS** - Page 6
6. **PROCESS MANAGEMENT TOOLS** - Page 7
7. **TEXT PROCESSING TOOLS** - Page 8
8. **COMPRESSION TOOLS** - Page 9
9. **PACKAGE MANAGEMENT** - Page 10
10. **TERMINAL ENHANCEMENTS** - Page 11
11. **ONE-LINE INSTALL SCRIPT** - Page 12

---

## 1. SYSTEM MONITORING TOOLS

### 📊 **htop** - Interactive Process Viewer
```bash
# Install
sudo apt update
sudo apt install htop -y

# Usage
htop                    # Interactive view
htop -u username        # Show user processes
htop -p PID1,PID2       # Monitor specific PIDs
htop -d 10              # Update every 10 seconds
```

### 📈 **glances** - Comprehensive System Monitor
```bash
# Install
sudo apt install glances -y
# OR with pip
pip3 install glances

# Usage
glances                 # Basic monitoring
glances -w              # Web server mode (port 61208)
glances --disable-plugin docker,ports  # Disable plugins
glances --export csv    # Export to CSV
```

### 🔍 **nmon** - Nigel's Monitor
```bash
# Install
sudo apt install nmon -y

# Usage
nmon                    # Interactive mode
nmon -f -s 30 -c 100    # Save to file, 30s interval, 100 snapshots
nmon -h                 # Help with all options
```

### 💾 **iotop** - Disk I/O Monitor
```bash
# Install
sudo apt install iotop -y

# Usage
sudo iotop              # Real-time I/O monitoring
sudo iotop -o           # Only show active I/O
sudo iotop -P           # Show processes only
sudo iotop -a           # Accumulated I/O
```

### 🌡️ **sensors** - Hardware Temperature
```bash
# Install
sudo apt install lm-sensors -y

# Usage
sudo sensors-detect     # Detect hardware sensors
sudo service kmod start
sensors                 # Show temperatures
watch -n 2 sensors      # Monitor every 2 seconds
```

### 📊 **dstat** - Versatile Resource Statistics
```bash
# Install
sudo apt install dstat -y

# Usage
dstat                   # Basic stats
dstat -cdngy            # CPU, disk, network, memory
dstat --top-cpu         # Top CPU processes
dstat --output file.csv # Export to CSV
```

---

## 2. NETWORK TOOLS

### 🌐 **net-tools** (Essential Network Commands)
```bash
# Install
sudo apt install net-tools -y

# Commands included:
ifconfig                # Network interface config
netstat                 # Network statistics
route                   # Routing table
arp                     # ARP table
iptunnel                # IP tunnels
```

### 🔗 **iproute2** (Modern Network Tools)
```bash
# Install
sudo apt install iproute2 -y

# Usage
ip addr show            # Show IP addresses (modern ifconfig)
ip route show           # Show routing table
ip link show            # Show network interfaces
ip neigh show           # Show ARP table
```

### 📡 **nmap** - Network Scanner
```bash
# Install
sudo apt install nmap -y

# Usage
nmap 192.168.1.1        # Basic scan
nmap -sS -sV target.com # Stealth scan with version detection
nmap -p 80,443,22 target # Scan specific ports
nmap -O target.com      # OS detection
nmap -A target.com      # Aggressive scan
```

### 🚦 **traceroute** / **mtr** - Network Path Analysis
```bash
# Install
sudo apt install traceroute mtr -y

# Usage
traceroute google.com   # Traditional traceroute
mtr google.com          # Real-time traceroute (better)
mtr -r -c 100 google.com # Generate report with 100 pings
```

### 📶 **iftop** / **nethogs** - Bandwidth Monitoring
```bash
# Install
sudo apt install iftop nethogs -y

# Usage
sudo iftop              # Real-time bandwidth by connection
sudo nethogs            # Bandwidth by process
sudo nethogs eth0       # Monitor specific interface
```

### 🔄 **curl** / **wget** - HTTP Tools
```bash
# Install
sudo apt install curl wget -y

# Usage
curl https://example.com                    # Fetch URL
curl -o file.txt https://example.com        # Save to file
curl -I https://example.com                 # Show headers only
wget https://example.com/file.zip           # Download file
wget -c https://example.com/bigfile.iso     # Continue interrupted download
```

### 📨 **mailutils** / **postfix** - Email Tools
```bash
# Install
sudo apt install mailutils postfix -y

# Usage
echo "Test email" | mail -s "Subject" user@example.com
mailq                   # Show mail queue
postqueue -p            # Alternative mail queue view
```

---

## 3. SECURITY TOOLS

### 🔒 **fail2ban** - Brute Force Protection
```bash
# Install
sudo apt install fail2ban -y

# Configuration
sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local
sudo nano /etc/fail2ban/jail.local

# Usage
sudo systemctl start fail2ban
sudo systemctl enable fail2ban
sudo fail2ban-client status
sudo fail2ban-client status sshd
```

### 🛡️ **ufw** - Uncomplicated Firewall
```bash
# Install
sudo apt install ufw -y

# Usage
sudo ufw enable                 # Enable firewall
sudo ufw default deny incoming  # Deny all incoming
sudo ufw default allow outgoing # Allow all outgoing
sudo ufw allow 22/tcp           # Allow SSH
sudo ufw allow 80,443/tcp       # Allow HTTP/HTTPS
sudo ufw status verbose         # Show status
sudo ufw delete allow 22/tcp    # Delete rule
```

### 🔑 **openssh-server** - SSH Server
```bash
# Install
sudo apt install openssh-server -y

# Configuration
sudo nano /etc/ssh/sshd_config

# Common config changes:
# Port 2222                    # Change default port
# PermitRootLogin no          # Disable root login
# PasswordAuthentication no   # Use keys only
# AllowUsers username         # Allow specific users

sudo systemctl restart ssh
```

### 👁️ **logwatch** - Log Analyzer
```bash
# Install
sudo apt install logwatch -y

# Usage
sudo logwatch --detail High   # Generate detailed report
sudo logwatch --service sshd  # SSH logs only
sudo logwatch --range yesterday # Yesterday's logs
```

### 🕵️ **lynis** - Security Audit
```bash
# Install
sudo apt install lynis -y

# Usage
sudo lynis audit system       # Full system audit
sudo lynis audit --tests-from-group malware # Specific tests
sudo lynis --quick            # Quick audit
```

### 🔍 **chkrootkit** / **rkhunter** - Rootkit Detection
```bash
# Install
sudo apt install chkrootkit rkhunter -y

# Usage
sudo chkrootkit               # Scan for rootkits
sudo rkhunter --check         # Run rkhunter scan
sudo rkhunter --update        # Update database
```

---

## 4. DEVELOPMENT TOOLS

### 🐍 **Python 3** & **pip**
```bash
# Install
sudo apt install python3 python3-pip python3-venv -y

# Usage
python3 --version
pip3 install package_name
python3 -m venv myenv
source myenv/bin/activate
```

### 📦 **Node.js** & **npm**
```bash
# Install (Ubuntu/Debian)
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Usage
node --version
npm --version
npm install package_name
npm init                  # Create package.json
```

### ☕ **Java** (OpenJDK)
```bash
# Install
sudo apt install default-jdk -y

# Usage
java --version
javac --version
```

### 🔧 **Build Essentials** (C/C++ Compiler)
```bash
# Install
sudo apt install build-essential -y

# Includes: gcc, g++, make, libc6-dev, etc.
# Usage
gcc --version
g++ --version
make --version
```

### 🗃️ **Git** - Version Control
```bash
# Install
sudo apt install git -y

# Usage
git --version
git clone https://github.com/user/repo.git
git status
git add .
git commit -m "message"
git push origin main
```

### 🐳 **Docker** & **Docker Compose**
```bash
# Install Docker
sudo apt install docker.io -y
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -aG docker $USER

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Usage
docker --version
docker-compose --version
docker ps
docker images
```

### 🗄️ **Database Clients**
```bash
# MySQL Client
sudo apt install mysql-client -y

# PostgreSQL Client
sudo apt install postgresql-client -y

# SQLite
sudo apt install sqlite3 -y

# Redis CLI
sudo apt install redis-tools -y

# MongoDB Shell
sudo apt install mongodb-clients -y
```

---

## 5. FILE MANAGEMENT TOOLS

### 📁 **rsync** - Remote File Sync
```bash
# Install
sudo apt install rsync -y

# Usage
rsync -avz source/ destination/            # Local copy
rsync -avz -e ssh user@host:/path/ local/ # Remote copy
rsync -avz --delete source/ dest/          # Mirror (delete extra)
rsync -avz --progress largefile.iso dest/  # Show progress
```

### 🗜️ **mc** - Midnight Commander (File Manager)
```bash
# Install
sudo apt install mc -y

# Usage
mc                      # Launch file manager
mc -b                   # Black & white mode
```

### 🔎 **locate** / **mlocate** - File Finder
```bash
# Install
sudo apt install mlocate -y

# Usage
sudo updatedb           # Update database
locate filename         # Find file
locate -i "*.txt"       # Case-insensitive
locate -c "*.conf"      # Count matches
```

### 📄 **tree** - Directory Tree
```bash
# Install
sudo apt install tree -y

# Usage
tree                    # Show current directory
tree -L 2               # Limit depth to 2
tree -d                 # Directories only
tree -I "node_modules"  # Ignore pattern
```

### 🔗 **ln** / **readlink** - Symbolic Links
```bash
# Built-in commands
ln -s /path/to/original /path/to/link  # Create symlink
readlink /path/to/link                 # Show symlink target
ls -l                                  # Show symlinks (l in permissions)
```

### 📏 **ncdu** - Disk Usage Analyzer
```bash
# Install
sudo apt install ncdu -y

# Usage
ncdu /home              # Analyze directory
ncdu -x /               # Don't cross filesystems
ncdu -o report.txt /    # Export to file
```

---

## 6. PROCESS MANAGEMENT TOOLS

### ⚙️ **ps** / **pgrep** / **pkill** - Process Control
```bash
# Built-in commands
ps aux                  # Show all processes
ps -ef | grep nginx     # Find specific process
pgrep -u username       # Find processes by user
pkill process_name      # Kill by name
kill -9 PID             # Force kill
killall process_name    # Kill all matching processes
```

### 🔄 **cron** - Scheduled Tasks
```bash
# Install
sudo apt install cron -y

# Usage
crontab -e              # Edit user crontab
crontab -l              # List cron jobs
sudo systemctl start cron
sudo systemctl enable cron

# Crontab format:
# * * * * * command
# │ │ │ │ │
# │ │ │ │ └── Day of week (0-7, Sunday=0/7)
# │ │ │ └──── Month (1-12)
# │ │ └────── Day of month (1-31)
# │ └──────── Hour (0-23)
# └────────── Minute (0-59)
```

### 🎯 **screen** / **tmux** - Terminal Multiplexer
```bash
# Install
sudo apt install screen tmux -y

# Screen usage:
screen                  # Start new session
screen -S session_name  # Named session
Ctrl+A then D           # Detach
screen -r               # Reattach
screen -ls              # List sessions

# Tmux usage:
tmux                    # Start new session
tmux new -s session_name
Ctrl+B then D           # Detach
tmux attach -t session_name
tmux ls                 # List sessions
```

### 📊 **at** / **batch** - One-time Scheduling
```bash
# Install
sudo apt install at -y

# Usage
echo "command" | at 14:30        # Run at specific time
at -f script.sh 14:30            # Run script
at now + 1 hour                  # Run in 1 hour
atq                              # List pending jobs
atrm job_number                  # Remove job
```

### 🚀 **systemd** - Service Management
```bash
# Built-in (modern systems)
systemctl status service_name    # Check status
systemctl start service_name     # Start service
systemctl stop service_name      # Stop service
systemctl restart service_name   # Restart service
systemctl enable service_name    # Enable auto-start
systemctl disable service_name   # Disable auto-start
systemctl list-units --type=service  # List all services
journalctl -u service_name       # View service logs
```

---

## 7. TEXT PROCESSING TOOLS

### ✂️ **grep** / **egrep** / **fgrep** - Pattern Search
```bash
# Built-in commands
grep "pattern" file.txt          # Basic search
grep -r "pattern" /path/         # Recursive search
grep -i "pattern" file.txt       # Case-insensitive
grep -v "pattern" file.txt       # Invert match
grep -c "pattern" file.txt       # Count matches
grep -n "pattern" file.txt       # Show line numbers
egrep "pattern1|pattern2" file.txt # Extended regex
```

### 🔤 **awk** - Text Processing Language
```bash
# Install (usually pre-installed)
sudo apt install gawk -y

# Usage
awk '{print $1}' file.txt        # Print first column
awk -F: '{print $1}' /etc/passwd # Use colon as delimiter
awk '/pattern/ {print $0}' file.txt # Print matching lines
awk 'NR==1,NR==5 {print $0}' file.txt # Lines 1-5
awk '{sum+=$1} END {print sum}' file.txt # Sum column
```

### 🎯 **sed** - Stream Editor
```bash
# Install (usually pre-installed)
sudo apt install sed -y

# Usage
sed 's/old/new/g' file.txt       # Replace all occurrences
sed -i 's/old/new/g' file.txt    # In-place edit
sed -n '5,10p' file.txt          # Print lines 5-10
sed '/pattern/d' file.txt        # Delete matching lines
sed '1i\New First Line' file.txt # Insert at line 1
```

### 📝 **vim** / **nano** - Text Editors
```bash
# Install
sudo apt install vim nano -y

# Vim usage:
vim file.txt                     # Open file
# Modes: Normal (Esc), Insert (i), Visual (v)
# Commands: :w (save), :q (quit), :wq (save & quit)

# Nano usage:
nano file.txt                    # Open file
# Ctrl+O: Save, Ctrl+X: Exit, Ctrl+W: Search
```

### 📄 **less** / **more** - File Viewers
```bash
# Built-in commands
less file.txt                    # View file (better)
more file.txt                    # View file (basic)
cat file.txt                     # Display entire file
head -n 10 file.txt              # First 10 lines
tail -n 10 file.txt              # Last 10 lines
tail -f logfile.log              # Follow (live view)
```

### 📊 **cut** / **paste** / **join** - Column Operations
```bash
# Built-in commands
cut -d: -f1 /etc/passwd          # Extract first field
cut -c1-10 file.txt              # Extract characters