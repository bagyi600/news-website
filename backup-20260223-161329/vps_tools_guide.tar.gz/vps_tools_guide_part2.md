paste file1.txt file2.txt          # Merge files side by side
join file1.txt file2.txt            # Join on common field
```

### 🔢 **sort** / **uniq** / **wc** - Text Analysis
```bash
# Built-in commands
sort file.txt                       # Sort alphabetically
sort -n file.txt                    # Sort numerically
sort -r file.txt                    # Reverse sort
sort -u file.txt                    # Unique sort
uniq file.txt                       # Remove consecutive duplicates
uniq -c file.txt                    # Count occurrences
wc file.txt                         # Word count (lines, words, chars)
wc -l file.txt                      # Line count only
```

### 📋 **column** / **pr** - Column Formatting
```bash
# Install
sudo apt install bsdmainutils -y  # For column command

# Usage
column -t data.txt                 # Format as table
ls -la | column -t                 # Format ls output
pr -2 file.txt                     # Two-column format
```

---

## 8. COMPRESSION TOOLS

### 📦 **tar** - Tape Archive
```bash
# Built-in command
tar -czvf archive.tar.gz /path/    # Create gzip compressed tar
tar -xzvf archive.tar.gz           # Extract gzip tar
tar -cjvf archive.tar.bz2 /path/   # Create bzip2 compressed tar
tar -xjvf archive.tar.bz2          # Extract bzip2 tar
tar -tvf archive.tar.gz            # List contents
```

### 🗜️ **gzip** / **gunzip** - GZIP Compression
```bash
# Install
sudo apt install gzip -y

# Usage
gzip file.txt                      # Compress (creates file.txt.gz)
gunzip file.txt.gz                 # Decompress
gzip -9 file.txt                   # Maximum compression
gzip -d file.txt.gz                # Alternative decompress
zcat file.txt.gz                   # View compressed file
```

### 📚 **bzip2** / **bunzip2** - BZIP2 Compression
```bash
# Install
sudo apt install bzip2 -y

# Usage
bzip2 file.txt                     # Compress (creates file.txt.bz2)
bunzip2 file.txt.bz2               # Decompress
bzcat file.txt.bz2                 # View compressed file
```

### 🗃️ **zip** / **unzip** - ZIP Archives
```bash
# Install
sudo apt install zip unzip -y

# Usage
zip archive.zip file1 file2        # Create zip
zip -r archive.zip /path/          # Recursive zip
unzip archive.zip                  # Extract
unzip -l archive.zip               # List contents
unzip -d /target/path archive.zip  # Extract to specific directory
```

### 📁 **7zip** - High Compression Ratio
```bash
# Install
sudo apt install p7zip-full -y

# Usage
7z a archive.7z file1 file2        # Create 7z archive
7z x archive.7z                    # Extract
7z l archive.7z                    # List contents
7z t archive.7z                    # Test archive
```

### 🔍 **file** - File Type Identification
```bash
# Install
sudo apt install file -y

# Usage
file document.pdf                  # Identify file type
file -i image.jpg                  # Show MIME type
file -z compressed.gz              # Look inside compressed files
```

---

## 9. PACKAGE MANAGEMENT

### 📦 **APT** - Advanced Package Tool (Debian/Ubuntu)
```bash
# Basic commands
sudo apt update                    # Update package lists
sudo apt upgrade                   # Upgrade installed packages
sudo apt install package_name      # Install package
sudo apt remove package_name       # Remove package
sudo apt purge package_name        # Remove package + config files
sudo apt autoremove                # Remove unused dependencies
sudo apt search "search_term"      # Search for packages
sudo apt show package_name         # Show package info
sudo apt list --installed          # List installed packages
sudo apt-cache policy package_name # Show version info
```

### 🔍 **dpkg** - Debian Package Manager
```bash
# Low-level package management
sudo dpkg -i package.deb           # Install .deb file
sudo dpkg -r package_name          # Remove package
sudo dpkg -P package_name          # Purge package
dpkg -l                            # List installed packages
dpkg -L package_name               # List files from package
dpkg -S /path/to/file              # Find which package owns file
```

### 🐚 **snap** - Universal Linux Packages
```bash
# Install snapd first
sudo apt install snapd -y

# Usage
sudo snap install package_name     # Install snap package
sudo snap remove package_name      # Remove snap
snap list                          # List installed snaps
sudo snap refresh                  # Update snaps
snap find "search_term"            # Search snaps
```

### 📦 **Flatpak** - Another Universal Package System
```bash
# Install flatpak
sudo apt install flatpak -y
sudo flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo

# Usage
flatpak install flathub app_id     # Install from Flathub
flatpak uninstall app_id           # Remove
flatpak list                       # List installed
flatpak update                     # Update
```

### 🔄 **alien** - Convert Package Formats
```bash
# Install
sudo apt install alien -y

# Usage
sudo alien -r package.rpm          # Convert RPM to DEB
sudo alien -d package.rpm          # Generate DEB (install with dpkg)
sudo alien -t package.rpm          # Convert to tarball
```

---

## 10. TERMINAL ENHANCEMENTS

### 🎨 **zsh** + **oh-my-zsh** - Better Shell
```bash
# Install zsh
sudo apt install zsh -y

# Install oh-my-zsh
sh -c "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)"

# Set as default shell
chsh -s $(which zsh)

# Popular plugins:
# git, docker, kubectl, python, node, npm, yarn, aws
```

### 🐚 **bash-completion** - Auto-completion
```bash
# Install
sudo apt install bash-completion -y

# Usage
# Auto-completes commands, files, directories
# Press Tab to auto-complete
```

### 📜 **history** Enhancements
```bash
# Add to ~/.bashrc or ~/.zshrc
export HISTSIZE=10000               # History size
export HISTFILESIZE=20000           # History file size
export HISTTIMEFORMAT="%d/%m/%y %T " # Timestamp format
export HISTCONTROL=ignoreboth       # Ignore duplicates and spaces
shopt -s histappend                 # Append to history file

# Commands
history                            # Show history
!number                            # Execute command from history
!!                                 # Last command
!string                            # Last command starting with string
Ctrl+R                             # Search history
```

### 🎯 **aliases** - Command Shortcuts
```bash
# Add to ~/.bashrc or ~/.bash_aliases
alias ll='ls -la'
alias la='ls -A'
alias l='ls -CF'
alias grep='grep --color=auto'
alias egrep='egrep --color=auto'
alias fgrep='fgrep --color=auto'
alias diff='colordiff'
alias mkdir='mkdir -pv'
alias h='history'
alias j='jobs -l'
alias ..='cd ..'
alias ...='cd ../..'
alias ....='cd ../../..'
alias c='clear'
alias ports='netstat -tulanp'
alias update='sudo apt update && sudo apt upgrade'
```

### 🎨 **lsd** - Modern ls Replacement
```bash
# Install
sudo apt install lsd -y

# Usage
lsd                                 # Basic listing
lsd -la                             # Long format
lsd --tree                          # Tree view
lsd --icon never                    # No icons
```

### 🐟 **fish** - Friendly Interactive Shell
```bash
# Install
sudo apt install fish -y

# Set as default
chsh -s $(which fish)

# Features: Auto-suggestions, syntax highlighting, web config
```

### 📁 **ranger** - Terminal File Manager
```bash
# Install
sudo apt install ranger -y

# Usage
ranger                              # Launch file manager
# Navigation: j/k (down/up), l (enter), h (back), q (quit)
```

### 🔍 **fzf** - Fuzzy Finder
```bash
# Install
sudo apt install fzf -y

# Usage
Ctrl+R                             # Search command history
Ctrl+T                             # Search files
**<Tab>                            # File search in shell
vim $(fzf)                         # Open selected file in vim
```

### 🎵 **neofetch** / **screenfetch** - System Info
```bash
# Install
sudo apt install neofetch screenfetch -y

# Usage
neofetch                           # Show system info with logo
screenfetch                        # Alternative
```

---

## 11. ONE-LINE INSTALL SCRIPT

### 🚀 **Complete VPS Setup Script**
```bash
#!/bin/bash
# Save as: setup_vps.sh
# Run: bash setup_vps.sh

echo "=== VPS TERMINAL TOOLS INSTALLATION ==="

# Update system
sudo apt update && sudo apt upgrade -y

# System Monitoring
sudo apt install -y htop glances nmon iotop lm-sensors dstat

# Network Tools
sudo apt install -y net-tools iproute2 nmap traceroute mtr iftop nethogs curl wget mailutils postfix

# Security Tools
sudo apt install -y fail2ban ufw openssh-server logwatch lynis chkrootkit rkhunter

# Development Tools
sudo apt install -y python3 python3-pip python3-venv build-essential git
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
sudo apt install -y default-jdk
sudo apt install -y docker.io
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
sudo usermod -aG docker $USER

# Database Clients
sudo apt install -y mysql-client postgresql-client sqlite3 redis-tools mongodb-clients

# File Management
sudo apt install -y rsync mc mlocate tree ncdu

# Process Management
sudo apt install -y cron screen tmux at

# Text Processing
sudo apt install -y vim nano gawk sed

# Compression Tools
sudo apt install -y gzip bzip2 zip unzip p7zip-full file

# Package Management Extras
sudo apt install -y snapd flatpak alien

# Terminal Enhancements
sudo apt install -y zsh bash-completion lsd fish ranger fzf neofetch screenfetch

# Install oh-my-zsh
if [ ! -d "$HOME/.oh-my-zsh" ]; then
    sh -c "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)" "" --unattended
fi

# Set up basic aliases
cat >> ~/.bashrc << 'EOF'
# Custom Aliases
alias ll='ls -la'
alias la='ls -A'
alias l='ls -CF'
alias grep='grep --color=auto'
alias update='sudo apt update && sudo apt upgrade'
alias ports='netstat -tulanp'
alias h='history'
alias c='clear'
alias ..='cd ..'
alias ...='cd ../..'
alias ....='cd ../../..'

# History settings
export HISTSIZE=10000
export HISTFILESIZE=20000
export HISTTIMEFORMAT="%d/%m/%y %T "
export HISTCONTROL=ignoreboth
shopt -s histappend
EOF

# Reload bashrc
source ~/.bashrc

echo "=== INSTALLATION COMPLETE ==="
echo "Installed tools:"
echo "1. System Monitoring: htop, glances, nmon, iotop, sensors, dstat"
echo "2. Network: net-tools, nmap, traceroute, iftop, curl, wget"
echo "3. Security: fail2ban, ufw, openssh-server, lynis"
echo "4. Development: python3, nodejs, git, docker, build-essential"
echo "5. File Management: rsync, mc, tree, ncdu"
echo "6. Text Processing: vim, nano, awk, sed"
echo "7. Terminal: zsh, oh-my-zsh, fzf, neofetch"
echo ""
echo "Next steps:"
echo "1. Configure firewall: sudo ufw enable"
echo "2. Set up SSH keys for secure access"
echo "3. Configure fail2ban for brute force protection"
echo "4. Set up regular updates with cron"
echo ""
echo "Log out and back in for all changes to take effect."
```

### 📋 **Quick Install Commands**

**Minimal Setup (Essential Tools Only):**
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y htop nano git curl wget net-tools ufw fail2ban python3 python3-pip build-essential
```

**Web Server Setup:**
```bash
sudo apt install -y nginx mysql-server php-fpm php-mysql certbot python3-certbot-nginx
sudo ufw allow 'Nginx Full'
sudo systemctl start nginx
sudo systemctl enable nginx
```

**Development Setup:**
```bash
sudo apt install -y git nodejs python3 python3-pip python3-venv docker.io docker-compose
sudo usermod -aG docker $USER
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
```

**Security Hardening:**
```bash
sudo apt install -y fail2ban ufw lynis rkhunter
sudo ufw enable
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo fail2ban-client status
```

---

## 12. USEFUL COMMAND CHEATSHEET

### 🔧 **System Information**
```bash
uname -a                          # Kernel version
lsb_release -a                    # Distribution info
cat /etc/os-release               # OS details
hostnamectl                       # Hostname and OS info
uptime                            # System uptime
who                               # Logged in users
w                                 # Who + what they're doing
last                              # Last logins
free -h                           # Memory usage
df -h                             # Disk space
du -sh /path                      # Directory size
lscpu                             # CPU info
lsblk                             # Block devices
lspci                             # PCI devices
lsusb                             # USB devices
```

### 🔍 **Process Management**
```bash
ps aux | grep process             # Find process
top                               # Interactive process viewer
kill -9 PID                       # Force kill process
pkill -f "pattern"               # Kill by pattern
killall process_name              # Kill all instances
nice -n 10 command               # Run with low priority
renice 10 PID                    # Change priority
nohup command &                  # Run in background
jobs                              # List background jobs
fg %1                            # Bring job 1 to foreground
bg %1                            # Continue job 1 in background
```

### 🌐 **Network Diagnostics**
```bash
ping google.com                   # Test connectivity
ping -c 4 google.com              # 4 pings only
traceroute google.com             # Network path
mtr google.com                    # Better traceroute
dig google.com                    # DNS lookup
nslookup google.com               # Alternative DNS
host google.com                   # Simple DNS
whois domain.com                  # Domain information
netstat -tulpn                    # Listening ports
ss -tulpn                         # Modern netstat
iptables -L                       # Firewall rules
route -n                          # Routing table
arp -a                            # ARP cache
```

### 📁 **File Operations**
```bash
cp -r source dest                 # Recursive copy
mv old new                        # Move/rename
rm -rf directory                  # Force remove directory
chmod 755 file                    # Change permissions
chown user:group file             # Change ownership
ln -s target linkname             # Create symlink
find /path -name "*.txt"         # Find files
find /path -type f -mtime -7     # Files modified last 7 days
locate pattern                    # Fast file search
updatedb                          # Update locate database
stat file.txt                     # File statistics
touch file.txt                    # Create empty file
mkdir -p path/to/dir              # Create nested directories
```

### 📊 **Performance Monitoring**
```bash
vmstat 1                         # Virtual memory stats
iostat 1                         # I/O statistics
mpstat 1                         # CPU statistics
sar -u 1 3                       # CPU usage (3 samples)
sar -r 1 3                       # Memory usage
sar -b 1 3                       # I/O statistics
pidstat 1                        # Process statistics
dstat 1                          # Combined statistics
iftop                            # Network bandwidth
iotop                            # Disk I/O
htop                             # Enhanced top
glances                          # Comprehensive monitor
```

### 🔒 **Security Checks**
```bash
sudo lastb                       # Failed login attempts
sudo tail -f /var/log/auth.log   # Authentication logs
sudo grep "Failed password" /var/log/auth.log
sudo netstat -tulpn | grep LISTEN # Open ports
sudo lsof -i :80                 # What's using port 80
sudo ps aux | grep -E "(ssh|ftp|telnet)" # Remote services
sudo find / -type f -perm -4000 -ls # SUID files
