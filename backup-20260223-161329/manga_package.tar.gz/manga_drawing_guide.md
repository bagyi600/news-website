# 🖌️ COMPLETE MANGA DRAWING GUIDE
## "Whispers of the Forest" - Step-by-Step Creation

## 📋 MATERIALS NEEDED

### **Traditional (Pen & Paper):**
- **Paper:** Manga manuscript paper (B4 size, 350gsm)
- **Pens:** G-pen (main lines), Maru pen (details), Spoon pen (effects)
- **Screens:** Tone sheets (10%, 20%, 30%, gradient)
- **White:** Correction fluid, white gel pen
- **Rulers:** French curve, circle template

### **Digital (Recommended):**
- **Software:** Clip Studio Paint EX (best for manga)
- **Tablet:** Wacom Intuos Pro or equivalent
- **Brushes:** Custom manga brush set
- **Screens:** Digital tone library
- **3D Models:** For perspective reference

## 🎨 STEP 1: CHARACTER DESIGN

### **Kaito - The Caretaker**
```
FACE STRUCTURE:
1. Start with oval shape
2. Add pronounced cheekbones (age)
3. Gentle jawline, not sharp
4. Forehead wrinkles like tree rings

EYES:
Shape: ▷---◁ (gentle downward slope)
Pupils: Large, reflective
Highlights: Two - one large (main), one small (reflection)
Eyelashes: Sparse, natural

HAIR:
Style: Silver, tied low
Texture: Fine lines showing individual hairs
Flow: Follows head shape, not rigid

CLOTHING:
Robe: Simple lines, loose fit
Folds: Natural drape, not stiff
Texture: Linen - show weave pattern subtly

HANDS:
Veins visible but not exaggerated
Slight arthritis in knuckles
Soil under nails (important detail)
```

### **Sakura - The Visitor**
```
TRANSFORMATION PROGRESSION:

PAGE 1 (Arrival):
- Stiff posture: shoulders up, back straight
- Tense face: furrowed brow, tight lips
- Clothing: Sharp lines, crisp folds
- Hair: Perfectly styled, unmoving

PAGE 2 (Beginning):
- Shoulders start to drop
- Expression: Confusion → curiosity
- Clothing: Starts to wrinkle naturally
- Hair: Strands come loose

PAGE 3 (Connection):
- Relaxed posture: natural curves
- Expression: Wonder, peace
- Clothing: Flows with movement
- Hair: Natural movement, some disarray

PAGE 4 (Integration):
- Balanced posture: neither stiff nor sloppy
- Expression: Content, aware
- Clothing: Mix of city and natural elements
- Hair: Natural but intentional
```

## 🌳 STEP 2: ENVIRONMENT DESIGN

### **The Ancient Forest**
```
TREES:
1. **Cedar Trees:** Tall, straight trunks
   Bark: Vertical striations
   Branches: Horizontal layers
   Foliage: Fluffy, cloud-like

2. **Maple Trees:** For color variation
   Leaves: Hand-shaped, detailed
   Bark: Smooth with horizontal lines

3. **Pine Trees:** For texture contrast
   Needles: Fine lines in clusters
   Bark: Plated, puzzle-like

FOREST FLOOR:
Layers (bottom to top):
1. Soil: Dark, textured
2. Moss: Velvety, soft edges  
3. Ferns: Delicate, lacy
4. Flowers: Small clusters
5. Fallen leaves: Overlapping

LIGHTING:
Time of day progression:
- Page 1: Golden hour (warm, long shadows)
- Page 2: Dusk (blue tones, fireflies)
- Page 3: Night (firelight, moonlight)
- Page 4: Morning (soft, diffuse)
```

### **The City (Contrast)**
```
BUILDINGS:
- Straight vertical lines
- Grid patterns for windows
- Reflective surfaces
- Hard shadows

PARK (Integration):
- Natural shapes within geometric city
- Trees: Pruned but alive
- Grass: Patchy but growing
- Bench: Man-made but weathered
```

## 📐 STEP 3: PANEL LAYOUT & COMPOSITION

### **Page 1 Layout Guide**
```
PAGE DIMENSIONS: B4 (257mm × 364mm)
SAFE AREA: 210mm × 297mm (keep art inside)

PANEL 1 (Wide establishing):
Size: 180mm × 80mm
Position: Top, full width
Content: Forest edge, Sakura small
Focus: Scale contrast (human vs nature)

PANEL 2 (Medium):
Size: 90mm × 70mm  
Position: Middle left
Content: Kaito emerging
Focus: Character introduction

PANEL 3 (Close-up):
Size: 100mm × 80mm
Position: Middle right
Content: Hand on tree
Focus: Connection theme

PANEL 4 (Small):
Size: 60mm × 40mm
Position: Bottom right
Content: Phone notification
Focus: Conflict (old vs new)
```

### **Page Flow Principles**
```
EYE FLOW: Z-pattern (Western) or right-to-left (traditional manga)
PACING: 
- Fast: Multiple small panels
- Slow: Large panels, full spreads
- Emotional: Close-ups, reaction shots

TRANSITIONS:
1. **Action-to-Action:** Sequential movement
2. **Subject-to-Subject:** Different views of same scene
3. **Scene-to-Scene:** Location/time change
4. **Aspect-to-Aspect:** Different elements of same moment
```

## 🖋️ STEP 4: INKING TECHNIQUES

### **Line Weight Hierarchy**
```
1. OUTLINES: 1.0pt (characters), 0.8pt (foreground), 0.5pt (background)
2. DETAILS: 0.3pt (facial features), 0.2pt (texture)
3. EFFECTS: 0.1pt (sparkles), variable (speed lines)

CHARACTER LINES:
- Contours: Thickest
- Clothing folds: Medium
- Facial features: Thin but precise
- Hair: Varying thickness for flow

NATURE LINES:
- Tree trunks: Thick, textured
- Branches: Medium, tapering
- Leaves: Thin, delicate
- Water: Curved, flowing
```

### **Brush Techniques**
```
G-PEN (Main lines):
- Pressure sensitive: Thick on downstrokes, thin on upstrokes
- Use for: Character outlines, major elements

MARU PEN (Details):
- Consistent line weight
- Use for: Facial features, fine details, patterns

SPOON PEN (Effects):
- Creates tapered lines
- Use for: Hair strands, grass, magical effects

SCREENTONE BRUSH:
- Digital only
- Use for: Shadows, textures, magical glows
```

## 🎭 STEP 5: EXPRESSIONS & BODY LANGUAGE

### **Sakura's Emotional Journey**
```
PAGE 1: STRESSED
- Eyes: Narrow, focused downward
- Mouth: Tight line, corners down
- Brow: Furrowed
- Shoulders: Hunched forward
- Hands: Clenched or gripping

PAGE 2: TRANSITION
- Eyes: Wider, looking around
- Mouth: Slightly open
- Brow: Relaxing
- Shoulders: Starting to drop
- Hands: Loosening

PAGE 3: WONDER
- Eyes: Large, reflective
- Mouth: Soft smile
- Brow: Smooth
- Shoulders: Relaxed
- Hands: Open, receptive

PAGE 4: PEACE
- Eyes: Gentle, half-closed
- Mouth: Natural smile
- Brow: Completely smooth
- Shoulders: Natural position
- Hands: Resting comfortably
```

### **Kaito's Consistent Wisdom**
```
BASELINE EXPRESSION:
- Eyes: Kind, knowing (slight crinkle)
- Mouth: Gentle smile (not toothy)
- Posture: Straight but relaxed
- Movements: Slow, deliberate

VARIATIONS:
- Teaching: Leaning slightly forward
- Listening: Head tilted, eyes closed
- Remembering: Looking upward/away
- Connecting: Eyes closed, serene
```

## 🌟 STEP 6: MAGICAL REALISM TECHNIQUES

### **The "Whisper" Effect**
```
VISUAL REPRESENTATION:
1. **Glow:** Soft white/gold outline around characters
2. **Particles:** Floating light specks (vary sizes)
3. **Distortion:** Slight warp in background
4. **Color Shift:** Desaturate surroundings, focus on subject

TREE MEMORIES:
Layer 1 (Base): Detailed bark texture
Layer 2 (Memory): 30% opacity, sepia tone
Layer 3 (Glow): Light emission from memory
Layer 4 (Connection): Lines connecting to character

FIREFLY EFFECT:
- Individual: Small circle with glow
- Groups: Form patterns (constellations)
- Movement: Trail lines (dotted)
- Lighting: Cast soft light on surroundings
```

### **Transparency & Overlay**
```
MEMORY SEQUENCE (Page 3, Panel 3):
1. Draw current scene fully
2. Create new layer at 40% opacity
3. Draw memory image (sepia)
4. Add glow effect around memory
5. Use eraser with soft edge to fade edges
6. Add connecting lines (dotted, glowing)

TIME LAPSE (Root growth):
1. Draw multiple states on separate layers
2. Set to different opacities (100% → 20%)
3. Arrange in sequence
4. Add motion lines between states
```

## 📖 STEP 7: DIALOGUE & TEXT

### **Speech Bubbles**
```
KAITO'S BUBBLES:
Shape: Organic, cloud-like
Tail: Curved, gentle
Font: Handwritten, slightly irregular
Size: Moderate, not overwhelming

SAKURA'S BUBBLES (Progression):
Page 1: Sharp corners, straight tails
Page 2: Rounding corners, curved tails  
Page 3: Organic shapes, flowing tails
Page 4: Balanced between organic and structured

THOUGHT BUBBLES:
Shape: Cloud with circle connects
Use: Internal monologue, realization
Font: Italic, smaller

CAPTION BOXES:
Position: Top/bottom of panel
Style: Simple rectangle
Use: Narration, time passage, location
```

### **Sound Effects (SFX)**
```
NATURAL SOUNDS:
- Rustling leaves: サラサラ (sarasara)
- Flowing water: さらさら (sarasara) 
- Bird song: ピヨピヨ (piyopiyo)
- Wind: ヒューヒュー (hyūhyū)
- Fire crackle: パチパチ (pachipachi)

MAGICAL SOUNDS:
- Whisper: ひそひそ (hisohiso)
- Glow: キラキラ (kirakira)
- Memory: ぼわん (bowan)
- Connection: つながる (tsunagaru)

PLACEMENT:
- Follow action direction
- Integrate with artwork
- Vary size for emphasis
- Use appropriate fonts
```

## 🎨 STEP 8: TONES & SHADING

### **Screentone Application**
```
BASIC TONES:
- Skin: 10-20% dot tone
- Clothing: 20-30% depending on material
- Shadows: 40-60% gradient
- Night: 70% with highlights erased

SPECIAL EFFECTS:
- Magic glow: Gradient from center
- Water: Wave pattern tone
- Bark: Texture overlay
- Light through leaves: Dappled pattern

DIGITAL TONES:
1. Select area with lasso tool
2. Apply base tone
3. Adjust density/angle
4. Add texture overlay
5. Erase for highlights
```

### **Lighting Consistency**
```
LIGHT SOURCES:
Page 1: Setting sun (warm, from side)
Page 2: Dusk (ambient, multiple)
Page 3: Fire + moon (contrast)
Page 4: Morning sun (soft, from above)

SHADOW RULES:
1. Consistent direction per scene
2. Soft edges for natural light
3. Hard edges for artificial light
4. Cast shadows show form
5. Core shadows define shape
```

## 🔄 STEP 9: PAGE FLOW & PACING

### **Reading Rhythm**
```
FAST PAGES (Action/Discovery):
- Many small panels
- Varied sizes and shapes
- Dynamic angles
- Action lines

SLOW PAGES (Emotion/Reflection):
- Fewer, larger panels
- Symmetrical layouts
- Static compositions
- Full-page spreads

TRANSITION PAGES:
- Mix of panel sizes
- Gradual changes
- Visual echoes between panels
- Thematic connections
```

### **Visual Echoes (Repetition)**
```
MOTIFS TO REPEAT:
1. Hand position (Pages 1, 3, 4)
2. Single leaf (every page)
3. Light beams (connecting scenes)
4. Circular patterns (wholeness)
5. Bare feet (connection to earth)

COLOR ECHOES:
- Sakura's clothing color shifts
- Kaito's consistent earthy tones
- Forest greens in city scenes
- City grays in forest scenes
```

## 📦 STEP 10: FINAL PREPARATION

### **File Preparation for Publication**
```
DIGITAL FORMAT:
- Resolution: 600 DPI (print), 300 DPI (web)
- Color Mode: Grayscale for print, RGB for web
- File Format: TIFF (print), PNG/JPEG (web)
- Layers: Keep separated for edits

TRADITIONAL PREP:
- Scan at 600 DPI
- Clean up dust/scratches
- Adjust levels for contrast
- Convert to appropriate format

EXPORT SETTINGS:
1. Flatten image
2. Apply sharpening (subtle)
3. Convert to appropriate color profile
4. Save with proper naming convention
```

### **Checklist Before Final**
```
✅ Character consistency across pages
✅ Lighting direction consistent per scene
✅ Panel flow follows reading direction
✅ Dialogue placement doesn't obscure art
✅ Tone application is even
✅ Sound effects integrated naturally
✅ Page numbers included
✅ Title page/credits complete
✅ File formats correct for intended use
```

## 🎯 PRO TIPS & TRICKS

### **Time-Saving Techniques**
```
1. **3D Models:** Use for perspective reference
2. **Brush Presets:** Save custom brushes for trees, leaves, etc.
3. **Texture Libraries:** Build collection of bark, fabric, etc.
4. **Character Turnarounds:** Draw front/side/back views first
5. **Background Reuse:** Modify existing backgrounds for different times

### **Common Mistakes to Avoid**
```
❌ Inconsistent character proportions
❌ Lighting from multiple directions
❌ Overcomplicated panel layouts
❌ Too much dialogue/text
❌ Ignoring reader's eye flow
❌ Inconsistent line weights
❌ Screentone moiré patterns
❌ Poor file organization
```

### **Workflow Optimization**
```
DAY 1: Script & Thumbnails
DAY 2: Pencils (rough)
DAY 3: Pencils (clean)
DAY 4: Inking
DAY 5: Tones & Effects
DAY 6: Dialogue & Text
DAY 7: Final checks & export
```

## 🌈 COLOR VERSION CONSIDERATIONS

### **If Creating Color Version**
```
PALETTE STRATEGY:
- Limited palette (5-7 main colors)
- Complementary schemes for contrast
- Analogous schemes for harmony
- Value contrast for readability

COLOR SYMBOLISM:
- Green: Growth, nature, peace
- Blue: Wisdom, calm, depth  
- Brown: Earth, stability, age
- Gold: Magic, value, light
- Gray: City, stress, separation

FLAT COLOR → SHADING:
1. Base colors (flat)
2. Shadows (multiply layer)
3. Highlights (screen layer)
4. Effects (add/glow layers)
5. Adjustments (color balance)
```

---

## 🎨 FINAL THOUGHTS

**Remember:** This manga is about feeling, not just seeing. Every line should convey emotion. Every panel should breathe. Every page should feel like a walk in the forest.

**Key to Success:** Balance between detail and simplicity. Show enough to immerse, leave enough to imagine.

**Most Important:** Enjoy the process. If you're feeling peaceful while drawing it, readers will feel peaceful while reading it.

**Happy creating!** 🖌️✨

---

**"The best art doesn't show you something new. It helps you see what was always there."**