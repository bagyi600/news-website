# 🎨 MANGA SCENE VISUAL DESCRIPTIONS

## SCENE 1: THE FOREST EDGE (Page 1, Panel 1)

**Visual Composition:**
```
[WIDE ESTABLISHING SHOT - Golden hour lighting]

FOREGROUND:
- Sakura in business attire (gray suit, heels)
- She holds a small suitcase
- Her shadow stretches long toward the forest
- Road ends abruptly at forest boundary

MIDDLEGROUND:
- Ancient stone torii gate covered in moss
- Worn path leading into darkness between trees
- Sunlight filters through leaves in beams

BACKGROUND:
- Towering cedar trees disappearing into mist
- Mountains faintly visible in distance
- Sky transitioning from orange to deep blue

DETAILS:
- Cherry blossom petals drifting across frame
- Small shrine fox statue watching silently
- Moss growing over abandoned stone lantern
```

**Emotional Tone:** Awe mixed with hesitation. The forest feels both inviting and intimidating.

## SCENE 2: THE FIRST MEETING (Page 1, Panel 2)

**Visual Composition:**
```
[MEDIUM SHOT - Eye level]

CHARACTERS:
- Kaito emerging from between two large trees
- Bare feet on thick moss carpet
- Simple linen robe, silver hair glowing in light
- Gentle smile with crow's feet around eyes

- Sakura taking a step back in surprise
- One hand raised slightly in defensive gesture
- Eyes wide, mouth slightly open

ENVIRONMENT:
- Dappled sunlight creating patterns on both characters
- Ferns and wildflowers at their feet
- Butterflies floating between them

FRAMING:
- Trees frame the scene like a natural doorway
- Negative space emphasizes the distance between them
- Leading lines draw eye from Sakura to Kaito
```

**Emotional Tone:** Mystery meeting modern anxiety. Ancient wisdom confronting urban stress.

## SCENE 3: THE WHISPER MOMENT (Page 2, Panel 4)

**Visual Composition:**
```
[FULL-PAGE SPREAD - Magical realism]

CENTRAL IMAGE:
- Sakura sitting cross-legged, eyes closed
- Her entire body glowing with soft golden light
- Hair floating as if underwater

MAGICAL ELEMENTS:
- Tree bark showing faint images:
  * Deer walking through snow (winter)
  * Blossoms falling (spring)
  * Children playing long ago (memory)
  * Storms weathering the tree (resilience)

- Fireflies forming constellations around her
- Leaves falling in slow motion, each one detailed
- Roots glowing beneath the soil, connecting to other trees

COLOR SCHEME:
- Sakura: Warm gold (#FFD700) glow
- Forest: Deep emerald greens (#006400)
- Memories: Sepia tones with hints of color
- Magic: Soft silver sparkles (#C0C0C0)
```

**Emotional Tone:** Transcendental peace. Connection awakening.

## SCENE 4: NIGHT BY THE FIRE (Page 3, Panel 1)

**Visual Composition:**
```
[NIGHT SCENE - Intimate framing]

LIGHTING:
- Warm firelight casting dancing shadows
- Moonlight filtering through canopy
- Fireflies providing additional points of light

CHARACTERS:
- Kaito tending small campfire
- Hands moving slowly, deliberately
- Firelight reflecting in wise eyes

- Sakura wrapped in blanket, leaning forward
- Face showing childlike wonder
- Firelight softening her features

DETAILS:
- Steaming cups of herbal tea between them
- Owl watching from nearby branch
- Stars visible through gaps in leaves
- Wood smoke rising in gentle spirals

FRAMING:
- Close crop, emphasizing intimacy
- Fire as central element connecting them
- Darkness surrounding but not threatening
```

**Emotional Tone:** Warmth, safety, wisdom-sharing. Intergenerational connection.

## SCENE 5: TREE MEMORIES (Page 3, Panel 3)

**Visual Composition:**
```
[CLOSE-UP WITH OVERLAY - Time visualization]

PRIMARY IMAGE:
- Sakura's hand touching ancient tree bark
- Bark texture highly detailed:
  * Deep grooves like wrinkles
  * Moss patches like age spots
  * Lichen patterns like constellations

OVERLAY IMAGES (semi-transparent):
1. **Ancient Times:**
   - Samurai resting under this tree (400 years ago)
   - Faint, ghostly image in sepia

2. **Recent Past:**
   - Kaito as young man planting a sapling
   - More vibrant but still translucent

3. **Seasons:**
   - Snow accumulating on branches (winter)
   - Cherry blossoms blooming (spring)
   - Green leaves rustling (summer)
   - Red leaves falling (autumn)

VISUAL EFFECTS:
- Hand glowing where it touches bark
- Memory images pulsing gently
- Particles of light drifting upward
```

**Emotional Tone:** Time collapsing. Personal smallness against nature's longevity.

## SCENE 6: THE RETURN TO CITY (Page 4, Panel 3)

**Visual Composition:**
```
[SPLIT SCREEN - Contrast and connection]

LEFT SIDE (CITY - DAY):
- Sakura at her office desk
- Modern, sterile environment
- BUT: Small changes:
  * Potted bonsai tree on desk
  * Window open to let in breeze
  * She's barefoot under desk
  * Smiling genuinely

- Colored in cool blues and grays
- Straight lines, right angles
- Digital clock showing 2:00 PM

RIGHT SIDE (FOREST - DAY):
- Kaito touching the same ancient tree
- Sunlight through leaves
- Birds flying overhead
- Peaceful expression

- Colored in warm greens and browns
- Curved lines, organic shapes
- Sundial shadow pointing to same "time"

CONNECTING ELEMENT:
- Same shaft of sunlight hits both scenes
- Same leaf pattern shadow on both sides
- Invisible line connecting their hands
```

**Emotional Tone:** Integration. The forest comes with her. Peace is portable.

## SCENE 7: FINAL SPREAD (Page 4, Panel 4)

**Visual Composition:**
```
[FULL-PAGE SPREAD - Circular composition]

CENTRAL IMAGE:
- Sakura sitting under a single city park tree
- Eyes closed, peaceful smile
- Hands resting on grass

VISUAL METAPHORS:
- Tree roots visible underground, connecting to:
  * Other park trees
  * Pipes and cables (city veins)
  * Eventually to the ancient forest

- Leaves rustling with same pattern as forest
- One particular leaf falls, and as it turns:
  Side A: City skyline reflection
  Side B: Forest canopy reflection

- People walking by in blur, but Sakura is still
- Pigeons instead of forest birds, but same behavior

TEXTURE:
- Grass blades individually drawn
- Bark texture similar to ancient tree
- Concrete and nature blending at edges

COLOR:
- Desaturated city colors brightening near Sakura
- Her personal space has forest color palette
- Gradual transition from gray to green
```

**Emotional Tone:** Completion. The lesson wasn't about staying in the forest, but bringing the forest with you.

## 🖌️ ARTISTIC NOTES FOR DRAWING

### **Line Quality:**
- **Nature:** Organic, flowing, varied line weights
- **City:** Sharp, consistent, geometric lines
- **Characters:** Clean lines with emotional detail in eyes/hands

### **Perspective:**
- **Forest scenes:** Low angles looking up at trees (awe)
- **Intimate scenes:** Eye level or slightly above (connection)
- **City scenes:** Higher angles looking down (overwhelm)

### **Negative Space:**
- Use empty space for:
  - Silence moments
  - Emotional impact
  - Reader reflection time

### **Panel Transitions:**
- **Slow moments:** Larger panels, fewer per page
- **Realizations:** Full-page spreads
- **Time passing:** Sequence of small panels

## 🌟 KEY VISUAL MOTIFS TO REPEAT

1. **The Hand-Tree Connection** - Appears in Pages 1, 3, and 4
2. **Light Through Leaves** - Creates natural "spotlights"
3. **Bare Feet on Earth** - Symbol of direct connection
4. **Circular Composition** - Everything connects back
5. **The Single Leaf** - Represents the whole forest

## 🎨 COLOR PALETTE PROGRESSION

### **Beginning (Page 1):**
- Cool blues/grays (Sakura's world)
- Hints of green at edges

### **Middle (Pages 2-3):**
- Warm golds/browns/greens
- Increasing saturation
- Magical accents (silver, gold)

### **End (Page 4):**
- Integration of both palettes
- City grays warmed with forest tones
- Final scene: Balanced, harmonious colors

## 📐 PANEL LAYOUT EXAMPLES

### **Page 1 Layout:**
```
[WIDE] [MEDIUM]
[CLOSE-UP] [SMALL]
```

### **Page 2 Layout:**
```
[VERTICAL]
[WIDE]
[SMALL][SMALL][SMALL]
[FULL SPREAD]
```

### **Page 3 Layout:**
```
[NIGHT SCENE]
[FLASHBACK - SEPIA]
[MAGICAL]
[CONNECTION]
```

### **Page 4 Layout:**
```
[MORNING]
[FAREWELL]
[SPLIT SCREEN]
[FINAL SPREAD]
```

## 💫 MAGICAL REALISM TECHNIQUES

1. **Subtle Glows** - Don't overdo it
2. **Transparent Layers** - Show multiple times simultaneously
3. **Pattern Recognition** - Natural patterns that look like faces, stories
4. **Scale Play** - Extreme close-ups next to wide shots
5. **Texture Focus** - Bark, moss, stone details tell stories

---

**"Every leaf is a page. Every tree is a library. Every forest is a universe of stories waiting to be heard."**