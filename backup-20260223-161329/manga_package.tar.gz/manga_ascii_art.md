# 🎨 MANGA SCENE VISUALIZATIONS (ASCII & Descriptions)

## SCENE 1: THE FOREST EDGE - ASCII REPRESENTATION

```
                    🌸  🌸
               🌸       🌸      🌸
          🌸                     🌸
     🏮━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━▶
     │                                    │
     │    🌳🌳🌳🌳🌳🌳🌳🌳🌳🌳🌳🌳🌳🌳🌳   │
     │  🌳        ANCIENT         🌳  │
     │ 🌳         FOREST          🌳 │
     │🌳                           🌳│
     │🌳    🌲🌲🌲🌲🌲🌲🌲🌲🌲🌲🌲   🌳│
     │🌳   🌲                    🌲  🌳│
     │🌳  🌲      🏯            🌲   🌳│
     │🌳 🌲                    🌲    🌳│
     │🌳🌲      🌞☁️☁️☁️       🌲     🌳│
     │🌳🌲                    🌲      🌳│
     │🌳🌲    👤👜           🌲       🌳│
     │🌳🌲━━━━━━━━━━━━━━━━━━━━━━━━━━━━━🌳│
     │🌳                                🌳│
     └──────────────────────────────────┘

     👤 = Sakura (business attire, stressed)
     🏯 = Moss-covered torii gate
     🌞 = Setting sun through trees
     🏮 = Stone lantern
     🌸 = Cherry blossom petals
```

## SCENE 2: CHARACTER DESIGNS

### **KAITO (The Caretaker)**
```
       ╭─────────────────╮
       │   SILVER HAIR   │
       │  tied back      │
       │    ┌─────┐      │
       │    │  👁️  │      │  Wrinkles like
       │    │ 👁️ 👁️ │      │  tree bark
       │    └─────┘      │
       │   gentle smile  │
       │                 │
       │  SIMPLE ROBE    │
       │  │         │    │
       │  │         │    │
       │  └─────────┘    │
       │    BARE FEET    │
       │    (  ) (  )    │
       ╰─────────────────╯

FEATURES:
- Age lines that look like tree rings
- Eyes that reflect forest colors
- Hands with soil under nails
- Always slightly glowing
```

### **SAKURA TRANSFORMATION**
```
BEFORE (City):           AFTER (Forest):
╭─────────────╮         ╭─────────────╮
│ 👔 Suit     │         │ 🌿 Linen    │
│ 💼 Briefcase│         │ 🍃 Barefoot │
│ ⌚ Watch     │         │ ⏳ No watch │
│ 😟 Stressed │         │ 😌 Peaceful │
│ 📱 Phone    │         │ 🌸 Flower   │
╰─────────────╯         ╰─────────────╯

EYE CHANGE:
Before: 👁️🔲 (tense, focused)  
After:  👁️🌿 (soft, reflective)

POSTURE:
Before: ┌─┐ (rigid)      After: ╭─╮ (relaxed)
        │ │                     │ │
        └─┘                     ╰─╯
```

## SCENE 3: THE WHISPER MOMENT - VISUAL MAP

```
          PAGE LAYOUT:
      ╔══════════════════════════╗
      ║      FULL-PAGE SPREAD    ║
      ║                          ║
      ║      🌳🌳🌳🌳🌳🌳🌳      ║
      ║    🌳              🌳    ║
      ║  🌳                  🌳  ║
      ║ 🌳      👤(GLOWING)    🌳 ║
      ║🌳      /    \         🌳║
      ║🌳     /      \        🌳║
      ║ 🌳   │        │      🌳 ║
      ║  🌳  │ MEMORIES│    🌳  ║
      ║    🌳│ IN BARK │  🌳    ║
      ║      🌳🌳🌳🌳🌳🌳🌳      ║
      ║                          ║
      ║  🔥🦋✨🍂🌸❄️🦌🌙  ║
      ║  (floating elements)     ║
      ╚══════════════════════════╝

MEMORIES IN BARK (clockwise from top):
1. ❄️ Winter deer
2. 🌸 Spring blossoms  
3. 👦 Children playing (old)
4. ⛈️  Storm weathering
5. 🌱 Sapling planting
6. 🎎 Festival long ago
7. 🐦 Birds nesting
8. 🌞 Sunrise through leaves
```

## SCENE 4: FIRELIGHT CONVERSATION - COMPOSITION

```
LIGHTING DIAGRAM:
          🌕 Moon
           │
           ↓
    ╭──────────────╮
    │              │
    │     🔥      │  Fire as center
    │    /   \     │  of conversation
    │   /  👤  \   │
    │  /  Kaito \  │
    │ ╱           ╲ │
    │╱    👤       ╲│
    │   Sakura      │
    │               │
    │  🍵  🍵       │  Tea cups
    │               │
    ╰──────────────╯

SHADOW PLAY:
Fire → Kaito's shadow: Wise, elongated
Fire → Sakura's shadow: Becoming softer
Moon → Tree shadows: Pattern on ground
Fireflies → Points of light: Connecting them
```

## SCENE 5: TREE OF TIME - VISUAL CONCEPT

```
TREE TRUNK CROSS-SECTION:
╔══════════════════════════════════════╗
║  OUTER BARK (Present)               ║
║  ┌────────────────────────────┐     ║
║  │  👤 Hand touching here     │     ║
║  │  🟡 Glowing contact point  │     ║
║  └────────────────────────────┘     ║
║                                      ║
║  GROWTH RINGS (Time layers):        ║
║  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ ║ ← 1 year ago
║  ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓ ║ ← 10 years ago
║  ███████████████████████████████████ ║ ← 100 years ago
║  ███████████████████████████████████ ║ ← 500 years ago
║                                      ║
║  MEMORIES AT EACH LAYER:            ║
║  • Recent: 🚗 Car passing (modern)  ║
║  • Medium: 🚲 Bicycle (1950s)       ║
║  • Old:    🐎 Horse carriage (1800s)║
║  • Ancient:🏹 Hunter (1600s)        ║
║                                      ║
║  ROOTS (Connections):               ║
║  ╭─╮ Other trees                    ║
║  │ │ Stream water                   ║
║  ╰─╯ Animal burrows                 ║
║      Fungal network                 ║
╚══════════════════════════════════════╝
```

## SCENE 6: CITY/FOREST SPLIT - DESIGN

```
SPLIT SCREEN COMPARISON:

╔══════════════════╦══════════════════╗
║      CITY        ║     FOREST       ║
╠══════════════════╬══════════════════╣
║ 🏢 Buildings     ║ 🌳 Trees         ║
║ ────────────     ║ ╭──────────╮     ║
║ │███████████│    ║ │/\/\/\/\/\|    ║
║ │███████████│    ║ │/\/\/\/\/\|    ║
║ ────────────     ║ ╰──────────╯     ║
║                  ║                  ║
║ 👤 At desk       ║ 👤 Touching tree ║
║ │┌─────┐│        ║ │╭─────╮│        ║
║ ││🌿   ││        ║ ││🌳   ││        ║
║ │└─────┘│        ║ │╰─────╯│        ║
║  ───────         ║  ═══════         ║
║                  ║                  ║
║ 🕑 Digital time  ║ ☀️ Sundial       ║
║   14:00:00       ║     II           ║
║                  ║                  ║
║ 🔊 Traffic noise ║ 🎶 Birdsong      ║
║ 💨 AC breeze     ║ 🌬️ Natural wind  ║
║ 💡 Fluorescent   ║ 🌞 Sunlight      ║
╚══════════════════╩══════════════════╝

CONNECTING ELEMENTS (across split):
1. Same sunbeam: ☀️ → 👤 → 👤
2. Same shadow pattern: 🍃 on both sides
3. Invisible line: 👤 ←──────→ 👤
4. Shared breath rhythm: 💨 ↔️ 🌬️
```

## SCENE 7: FINAL INTEGRATION - CIRCULAR COMPOSITION

```
CIRCULAR LAYOUT:
              CITY
         ╭───────────╮
         │           │
         │   PARK    │
         │           │
         │    🌳     │
         │   /👤\    │
         │  /  |  \  │
FOREST ←─┤ /   |   \ ├─→ FOREST
         │/    |    \│
         │     |     │
         │ ROOTS     │
         │ CONNECT   │
         │ TO        │
         │ EVERYTHING│
         ╰───────────╯
              CITY

ROOT CONNECTIONS:
🌳 → 🏢 (Building foundations)
🌳 → 🚇 (Subway tunnels)  
🌳 → 💧 (Water pipes)
🌳 → 🔌 (Power lines)
🌳 → 🌳 (Other city trees)
🌳 → 🌲 (Distant forest)

LEAF SYMBOLISM:
Falling leaf shows:
TOP SIDE: 🏙️ City reflection
UNDER SIDE: 🌲 Forest reflection
EDGE: 👤 Tiny reflection of Sakura
```

## 🎨 COLOR PROGRESSION CHART

```
PAGE 1: CITY → FOREST TRANSITION
┌───┬──────────────┬──────────────┐
│   │  Sakura      │  Background  │
├───┼──────────────┼──────────────┤
│Start│#808080 (Gray)│#4682B4 (Steel)│
│   │#FFFFFF (White)│#B0C4DE (Light)│
├───┼──────────────┼──────────────┤
│Mid  │#D2B48C (Tan) │#228B22 (Forest)│
│   │#8B4513 (Saddle)│#006400 (Dark) │
├───┼──────────────┼──────────────┤
│End  │#F5DEB3 (Wheat)│#2E8B57 (Sea)  │
│   │#DEB887 (Burly) │#8FBC8F (Dark) │
└───┴──────────────┴──────────────┘

PAGE 4: INTEGRATION PALETTE
City elements: #A9A9A9 (DarkGray) + #20% Forest colors
Forest elements: #556B2F (DarkOlive) + #20% City colors
Sakura: #FFE4B5 (Moccasin) - Balanced between both
```

## 📐 PANEL FLOW DIAGRAM

```
PAGE 1: INTRODUCTION
┌───────┬───────┐
│ WIDE  │ MEDIUM│
├───────┴───────┤
│   CLOSE-UP    │
│   [Tree hand] │
├───────────────┤
│    SMALL      │
│   [Phone]     │
└───────────────┘

PAGE 2: TRANSFORMATION  
┌───────────────┐
│   VERTICAL    │
│  [Can't sit]  │
├───────────────┤
│     WIDE      │
│   [Stream]    │
├───┬───┬───┬───┤
│S1 │S2 │S3 │S4 │ ← Sequence
├───┴───┴───┴───┤
│   FULL PAGE   │
│   [Awakening] │
└───────────────┘

PAGE 3: CONNECTION
┌───────────────┐
│   [Fire]      │
│   Night       │
├───────────────┤
│ [Flashback]   │
│   Sepia       │
├───────────────┤
│  [Magical]    │
│ Tree memories │
├───────────────┤
│ [Silence]     │
│   Together    │
└───────────────┘

PAGE 4: INTEGRATION
┌───────────────┐
│ [Morning]     │
│   Changed     │
├───────────────┤
│ [Farewell]    │
│ Forest edge   │
├───────┬───────┤
│ CITY  │FOREST │ ← Split screen
├───────┴───────┤
│   FINAL       │
│   SPREAD      │
│ [Carry with]  │
└───────────────┘
```

## 🖌️ BRUSH STROKE GUIDE

### **For Nature:**
```
Trees:   /\/\/\/\    (Organic, varied)
Leaves:  ··°°··°°    (Random clusters)
Water:   ~~~~~~      (Flowing curves)
Stone:   ░▒▓█▓▒░    (Textured, rough)
```

### **For City:**
```
Buildings: │││││││   (Straight, uniform)
Windows:   ░█░░█░    (Grid pattern)
Roads:     ───────   (Smooth lines)
```

### **For Magic:**
```
Glow:      °·.·°·.·°  (Soft particles)
Memory:    [ghosted]  (50% opacity)
Connection:···⭑···⭑··· (Dotted lines)
```

## 🌟 KEY SYMBOLS TO USE THROUGHOUT

1. **The Single Leaf** 🍃 - Appears in every major scene
2. **Bare Footprints** 👣 - Show connection to earth
3. **Light Beams** ☀️→ - Connect different worlds
4. **Circular Patterns** ⭕ - Everything connects
5. **Hand Position** 🤲 - Open, receiving

---

**"Art isn't what you see, but what you help others see."**